---
title: Montréal Artificial Intelligence
---
## AVIS LÉGAL - LEGAL NOTICE

​![Montréal Artificial Intelligence : LEGAL NOTICE](../images/9thJune2011h1355DryFlatAcrylicPaint1440.jpg "Montréal Artificial Intelligence : LEGAL NOTICE")

__​​Publication Information [*Executive Order: HQ III M[5-X]*] :__
​​
__​​​​​​Approval Authority :__  Vincent Boucher, Founding Chairman and Secretary-General at Montréal.AI.
​​
__​​Office of Primary Responsibility :__ The Canada Strategic Information Analysis Council Inc.

__THIS IS A MONTREAL.AI SOFTWARE / SYSTEM.__

__MATERIALS PROVIDED IN THIS SOFTWARE / SYSTEM ARE PROVIDED WITHOUT WARRANTY OF ANY KIND AND DOES NOT CONSTITUTE ENDORSEMENT.__ THIS SOFTWARE / SYSTEM IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL MONTREAL.AI, THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THIS SOFTWARE / SYSTEM OR THE USE OR OTHER DEALINGS IN THIS SOFTWARE / SYSTEM.


__EVIDENCE OF UNAUTHORIZED USE MAY BE PROVIDED TO APPROPRIATE PERSONNEL FOR ADMINISTRATIVE, CRIMINAL OR OTHER LEGAL ACTION.__
​
​​​​![Montréal Artificial Intelligence : LEGAL NOTICE](../images/JusticeHQIIIM5.jpg "Montréal Artificial Intelligence : LEGAL NOTICE")
​
​✉️ Email Us : info@montreal.ai
​🌐 Website : http://www.montreal.ai/
​
​#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealArtificialIntelligence__
