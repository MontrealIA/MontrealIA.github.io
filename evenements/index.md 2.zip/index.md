---
title: MONTRÉAL.IA | Intelligence artificielle Montréal
---
## **ÉVÉNEMENTS DE MONTRÉAL.IA**

### **Dîner de presse | Concert | Vente aux enchères | Gala de bienfaisance**

![Les événements de Montréal.IA](../images/QuebecIAv6WhatIsAI1440x1440.jpg "Les événements de Montréal.IA")

## **❖ Événements de classe mondiale de MONTRÉAL.IA**

### _**AI DEBATE 2 : MARQUEZ VOTRE CALENDRIER - Détails à venir !**_

[![Événements de classe mondiale de Montréal.IA | AI DEBATE 2 : MARQUEZ VOTRE CALENDRIER — Détails à venir!](../images/aidebatetwo2560v0.jpg "Événements de classe mondiale de Montréal.IA | AI DEBATE 2 : MARQUEZ VOTRE CALENDRIER — Détails à venir!")](https://aidebate.eventbrite.ca)

**C'est le débat que le monde de l'intelligence artificielle attendait...**

### Billets et réservation de groupe

RETRANSMISSION EN DIRECT : https://aidebate.eventbrite.ca

__Date et heure :__ mercredi 23 décembre 2020 | 17:00 à 20:00 (heure de Montréal)

***

### _(**Événement précédent**) AI DEBATE 1 : Yoshua Bengio | Gary Marcus_

[![Événements de classe mondiale de Montréal.IA — AI DEBATE 1 : Yoshua Bengio | Gary Marcus](../images/bengio-marcus.jpg "Événements de classe mondiale de Montréal.IA — AI DEBATE 1 : Yoshua Bengio | Gary Marcus")](https://montrealartificialintelligence.com/aidebate/)

À l’agora de Mila, à Montréal, le lundi 23 décembre 2019, de 18h30 à 20h30 (heure de l'Est), Gary Marcus et Yoshua Bengio ont débattu sur la meilleure voie à suivre pour l'IA. ZDNet a décrit l'événement organisé par MONTRÉAL.IA comme un [“événement historique”](https://www.zdnet.com/article/devils-in-the-details-in-bengio-marcus-ai-debate/). 5,225 billets ont été réservés pour l'événement en direct. [Compte-rendu du débat sur l'IA](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/).

Des **diapositives, vidéos, lectures** et autres sont disponibles sur la [page web](https://montrealartificialintelligence.com/aidebate/) du débat de **MONTRÉAL.IA**.

**MONTRÉAL.IA** est reconnaissante envers [Gary Marcus](http://garymarcus.com), [Yoshua Bengio](https://mila.quebec/en/yoshua-bengio/), [Mila - Institut Québécois d'Intelligence Artificielle](https://mila.quebec/) et envers l'[écosystème collaboratif de Montréal en matière d'IA](https://www.facebook.com/groups/MontrealAI/). Un remerciement spécial à [Sasha Lu](https://sashaluccioni.com).

[![100 pays et 1000 villes](../images/attendeescity.jpeg "100 pays et 1000 villes")](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/)

***

## **❖ SYMPOSIUM QUÉBEC IA**

### _Stimuler l’activité économique, la recherche et l’innovation en IA au Québec_

[![SYMPOSIUM QUÉBEC IA — Stimuler l’activité économique, la recherche et l’innovation en IA au Québec](../images/quebecaisymposium.png "SYMPOSIUM QUÉBEC IA — Stimuler l’activité économique, la recherche et l’innovation en IA au Québec")](https://quebecaisymposium.eventbrite.ca)

Le **SYMPOSIUM QUÉBEC IA**, administré par [MONTRÉAL.IA](http://www.montreal.ai) et [QUÉBEC.IA](http://www.quebec.ai), est un événement visant à stimuler l'activité économique, la recherche et l'innovation en intelligence artificielle au Québec et ainsi contribuer à la compétitivité et au rayonnement du Québec sur les plans national et international.

### Billets et réservation de groupe

__Réservation de groupe:__ secretariat@montreal.ai

__Billets:__ https://quebecaisymposium.eventbrite.ca

__Date et heure:__ __Mercredi 7 octobre 2020 | 9:30 à 20:30 (heure de Montréal)__
__Location: Détails à annoncer__

__Site web:__ http://quebecaisymposium.com

***

## **❖ Célébration des chefs de file de l'industrie de l'IA**

### _Hommage aux chefs de file primés de l'industrie de l'IA & des sommités_

***

## **❖ Dîner de presse de MONTRÉAL.IA**

### _Hommage au journalisme en IA méritant_

***

## **❖ Vente aux enchères des beaux-arts de MONTRÉAL.IA**

### _Dévoilement d'un monde de secrets cachés..._

![La vente aux enchères des beaux-arts de MONTRÉAL.IA : un monde de secrets cachés à dévoiler...](../images/AITrillion1440.jpg "La vente aux enchères des beaux-arts de MONTRÉAL.IA : un monde de secrets cachés à dévoiler...")

Le 25 octobre 2018, [la première œuvre d'art en intelligence artificielle jamais vendue par la maison de ventes aux enchères Christie's a bouleversé les attentes, atteignant 432 500 $](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Aujourd'hui, la _Maison des Beaux-Arts de Montréal.IA_ présente : _La vente aux enchères des Beaux-Arts de Montréal.IA_, la **première vente aux enchères internationale consacrée à la quintessence des Beaux-Arts de l'IA**.

> "**_Les artistes qui créent avec AI ne suivront pas les tendances, ils les définiront._**" — Montréal.IA

Nous nous préparons pour la première vente aux enchères.

Les plus grands collectionneurs d'œuvres d'art pourront faire des offres à l'échelle internationale.

***

## **❖ Salon de MONTRÉAL.IA**

### _Rassemblement de gens sous le toit d'un hôte inspirant_

![Le salon MONTRÉAL.IA](../images/montrealiasalonv2.jpg "Le salon MONTRÉAL.IA s’inscrit dans la plus pure tradition des salons littéraires et philosophiques français du XV IIIème siècle.")

Le salon MONTRÉAL.IA s’inscrit dans la plus pure tradition des salons littéraires et philosophiques français du XV IIIème siècle. Débats et joutes d’idées en compagnie d’invités s’étant illustrés.

***

## **❖ Intelligence artificielle 101 | Webinaire international**

### _Un tutoriel de 75 minutes bien conçu et pratique_

Le __Secrétariat général de Montréal.IA__ présente, avec savoir-faire: "__*AI 101 Webinar*__: *The First World-Class Overview of AI for the General Public*".

__Lieu : Il s'agit d'un événement en ligne.__

[![ARTIFICIAL INTELLIGENCE 101 - INTERNATIONAL WEBINAR](../images/AI101Webinar2560v2.jpg "ARTIFICIAL INTELLIGENCE 101 - INTERNATIONAL WEBINAR")](https://ai101webinar.eventbrite.ca)

<a href="https://www.eventbrite.ca/e/artificial-intelligence-101-international-webinar-tickets-65144278290?ref=ebtn" target="_blank"><img src="https://www.eventbrite.ca/custombutton?eid=54093711748" alt="Eventbrite - ARTIFICIAL INTELLIGENCE 101 INTERNATIONAL WEBINAR" /></a>

__L'intelligence artificielle ouvre un monde de nouvelles possibilités.__ Ce __webinaire__ expose les principes fondamentaux de l'intelligence artificielle afin de fournir aux participants-es de puissants outils d'IA pour *__apprendre__*, *__déployer__* and *__faire avancer__* l'intelligence artificielle.

__Aperçu du programme (*“Instituer une compréhension percutante l’IA”*) et billets:__ https://ai101webinar.eventbrite.ca

<div id="eventbrite-widget-container-65144278290"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '65144278290',
        iframeContainerId: 'eventbrite-widget-container-65144278290',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Langue:__ Ce cours (*webinaire*) destiné à une audience internationale est en __anglais__.

Les participant(e)s recevront un lien pour se joindre à l’événement juste avant celui-ci.

***

## **❖ Conversation au coin du feu de MONTRÉAL.IA**

***

## **❖ Académie de MONTRÉAL.IA : IA 101**

### _Instituer une compréhension percutante de l'IA_

### **IA 101 : Pour les novices en intelligence artificielle !**

**Le mercredi, 11 mars 2020 19:00 – 20:30**, le __Secrétariat général de MONTRÉAL.IA__ présentera, avec savoir-faire : "__*Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public*__".

__Lieu : NRH Prince Arthur - Salle de bal, 3625, avenue du Parc, Montréal (Québec), Canada, H2X 3P8.__

<div id="eventbrite-widget-container-80189080699"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '80189080699',
        iframeContainerId: 'eventbrite-widget-container-80189080699',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

### Billets et réservation de groupe

__Réservation de groupe :__ secretariat@montreal.ai

__Billets :__ https://intelligenceartificielle101.eventbrite.ca

__Langue:__ La présentation sera en __français__. *Le matériel de référence sera dans sa langue originale*.
__Date et heure :__ Mercredi, 11 mars 2020 | 19:00 – 20:30
__Lieu : NRH Prince Arthur - Salle de bal, 3625, avenue du Parc, Montréal (Québec), Canada, H2X 3P8.__

> "**_(L'IA) comptera parmi nos plus grandes réalisations technologiques, et tout le monde mérite de jouer un rôle dans son élaboration._**" — Fei-Fei Li

***

## **❖ Dîner des ambassadeurs de MONTRÉAL.IA**

***

## **❖ MONTREAL.AI MIXER _(RÉUNION de MONTRÉAL.IA)_**

### _Orchestrer des synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA de Montréal_

[![MONTREAL.AI MIXER — Orchestrer les synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA à Montréal.](../images/MontrealAIMixerv2.jpg "MONTREAL.AI MIXER — Orchestrer les synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA à Montréal.")](https://aimixer.eventbrite.ca)

### Billets et réservation de groupe

__Réservation de groupe :__ secretariat@montreal.ai

__Billets :__ https://aimixer.eventbrite.ca

__Date et heure :__ __Jeudi, 11 juin 2020 | 17:30 à 19:30 (heure de Montréal)__
__Lieu : Détails à annoncer__

***

## **❖ Orchestre de MONTRÉAL.IA**

### _Des symphonies pionnières surhumaines_

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ Gala du Mérite philanthropique de MONTRÉAL.IA**

> "**_C'est le printemps pour l'IA, et nous prévoyons un long été._**" — Bill Braun, CIO de Chevron

✉️ __Courriel__ : info@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.montreal.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Montréal.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif*

#__IntelligenceArtificielle__ #__IntelligenceArtificielleMontreal__ #__MontrealIA__
