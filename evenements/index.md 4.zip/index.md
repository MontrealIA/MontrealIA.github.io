---
title: MONTRÉAL.IA | Intelligence artificielle Montréal
---
## **ÉVÉNEMENTS DE MONTRÉAL.IA**

### **Dîner de presse | Concert | Vente aux enchères | Gala de bienfaisance**

![Les événements de Montréal.IA](../images/QuebecIAv6WhatIsAI1440x1440.jpg "Les événements de Montréal.IA")

## **❖ Célébration des chefs de file de l'industrie de l'IA**

### _Hommage aux chefs de file primés de l'industrie de l'IA & des sommités_

***

## **❖ Dîner de presse de MONTRÉAL.IA**

### _Hommage au journalisme en IA méritant_

***

## **❖ Vente aux enchères des beaux-arts de MONTRÉAL.IA**

### _Dévoilement d'un monde de secrets cachés..._

![La vente aux enchères des beaux-arts de MONTRÉAL.IA : un monde de secrets cachés à dévoiler...](../images/AITrillion1440.jpg "La vente aux enchères des beaux-arts de MONTRÉAL.IA : un monde de secrets cachés à dévoiler...")

Le 25 octobre 2018, [la première œuvre d'art en intelligence artificielle jamais vendue par la maison de ventes aux enchères Christie's a bouleversé les attentes, atteignant 432 500 $](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Aujourd'hui, la _Maison des Beaux-Arts de Montréal.IA_ présente : _La vente aux enchères des Beaux-Arts de Montréal.IA_, la **première vente aux enchères internationale consacrée à la quintessence des Beaux-Arts de l'IA**.

> "**_Les artistes qui créent avec AI ne suivront pas les tendances, ils les définiront._**" — Montréal.IA

Nous nous préparons pour la première vente aux enchères.

Les plus grands collectionneurs d'œuvres d'art pourront faire des offres à l'échelle internationale.

***

## **❖ Salon de MONTRÉAL.IA**

### _Rassemblement de gens sous le toit d'un hôte inspirant_

***

## **❖ Conversation au coin du feu de MONTRÉAL.IA**

***

## **❖ Académie de MONTRÉAL.IA : IA 101**

### _Instituer une compréhension percutante de l'IA_

### **IA 101 : Pour les novices en intelligence artificielle !**

**Le mercredi, 11 mars 2020 19:00 – 20:30**, le __Secrétariat général de MONTRÉAL.IA__ présentera, avec savoir-faire : "__*Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public*__".

__Lieu : NRH Prince Arthur - Salle de bal, 3625, avenue du Parc, Montréal (Québec), Canada, H2X 3P8.__

<div id="eventbrite-widget-container-80189080699"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '80189080699',
        iframeContainerId: 'eventbrite-widget-container-80189080699',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

### Billets et réservation de groupe

__Réservation de groupe :__ secretariat@montreal.ai

__Billets :__ https://intelligenceartificielle101.eventbrite.ca

__Langue:__ La présentation sera en __français__. *Le matériel de référence sera dans sa langue originale*.
__Date et heure :__ Mercredi, 11 mars 2020 | 19:00 – 20:30
__Lieu : NRH Prince Arthur - Salle de bal, 3625, avenue du Parc, Montréal (Québec), Canada, H2X 3P8.__

> "**_(L'IA) comptera parmi nos plus grandes réalisations technologiques, et tout le monde mérite de jouer un rôle dans son élaboration._**" — Fei-Fei Li

***

## **❖ Dîner des ambassadeurs de MONTRÉAL.IA**

***

## **❖ Orchestre de MONTRÉAL.IA**

### _Des symphonies pionnières surhumaines_

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ Gala du Mérite philanthropique de MONTRÉAL.IA**

> "**_C'est le printemps pour l'IA, et nous prévoyons un long été._**" — Bill Braun, CIO de Chevron

✉️ __Courriel__ : info@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.montreal.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Montréal.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif*

#__IntelligenceArtificielle__ #__IntelligenceArtificielleMontreal__ #__MontrealIA__
