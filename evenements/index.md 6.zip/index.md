---
title: MONTRÉAL.IA | Intelligence artificielle Montréal
---
## **ÉVÉNEMENTS DE MONTRÉAL.IA**

### **Dîner de presse | Concert | Vente aux enchères | Gala de bienfaisance**

![Les événements de Montréal.IA: Dîner de presse | Concert | Vente aux enchères | Gala de bienfaisance](../images/QuebecIAv6WhatIsAI1440x1440.jpg "Les événements de Montréal.IA: Dîner de presse | Concert | Vente aux enchères | Gala de bienfaisance")

## **❖ Célébration des chefs de file de l'industrie de l'IA**

### _Hommage aux chefs de file primés de l'industrie de l'IA & des sommités_

***

## **❖ Dîner de presse de MONTRÉAL.IA**

### _Hommage au journalisme en IA méritant_

***

## **❖ Série de débats sur l'IA de MONTREAL.IA**

### **DÉBAT AI 2: 23 décembre 2020, 16h00 - 19h00 HNE | "Faire avancer l'IA: une approche interdisciplinaire"**

[![Série de débats sur l'IA de MONTREAL.IA | AI DEBATE 2](../images/aidebate2mosaic1440x720v8.jpg "Série de débats sur l'IA de MONTREAL.IA | AI DEBATE 2")](https://montrealartificialintelligence.com/aidebate2/)

#### **Programme**

**Panel 1**: _Architecture et défis_

**Panel 2**: _Regards sur les neurosciences et la psychologie_

**Panel 3**: _Vers une IA sur laquelle nous pouvons faire confiance_

#### **Conférenciers confirmés**

- _**Ryan Calo**_;
- _**Yejin Choi**_;
- _**Daniel Kahneman**_;
- _**Celeste Kidd**_;
- _**Christof Koch**_;
- _**Luis Lamb**_;
- _**Fei-Fei Li**_;
- _**Adam Marblestone**_;
- _**Margaret Mitchell**_;
- _**Robert Osazuwa Ness**_;
- _**Judea Pearl**_;
- _**Francesca Rossi**_;
- _**Ken Stanley**_;
- _**Rich Sutton**_;
- _**Doris Tsao**_; et
- _**Barbara Tversky**_.

Modérateur et co-organisateur (avec _Vincent Boucher_): _**Gary Marcus**_

__Site Web du "*AI Debate 2*:__ https://montrealartificialintelligence.com/aidebate2/

{% youtube VOI3Bb3p4GM %}

__Vidéo officielle du "*AI Debate 2*":__ https://youtu.be/VOI3Bb3p4GM

Faire partie de la conversation sur les réseaux sociaux: #**AIDebate2**

***

### **AI DEBATE 3: 23 décembre 2021, 16h00 - 19h00 EST**

[![Série de débats sur l'IA de MONTREAL.IA | AI DEBATE 3](../images/aidebate3v0.jpg "Série de débats sur l'IA de MONTREAL.IA | AI DEBATE 3")](https://aidebate3.eventbrite.ca)

__Site Web du "*AI Debate 3*:__ https://montrealartificialintelligence.com/aidebate3/

### **Billets et réservation de groupe**

**RSVP:** https://aidebate3.eventbrite.ca

__Date et heure:__ Thu, December 23, 2021, 4:00 PM – 7:00 PM EST

<div id="eventbrite-widget-container-133817911977"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '133817911977',
        iframeContainerId: 'eventbrite-widget-container-133817911977',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

Faire partie de la conversation sur les réseaux sociaux: #**AIDebate3**

***

### **AI DEBATE 1: 23 décembre 2020, 18h30 - 20h30 HNE | "Yoshua Bengio | Gary Marcus"**

[![Événements de classe mondiale de Montréal.IA — AI DEBATE 1 : Yoshua Bengio | Gary Marcus](../images/bengio-marcus.jpg "Événements de classe mondiale de Montréal.IA — AI DEBATE 1 : Yoshua Bengio | Gary Marcus")](https://montrealartificialintelligence.com/aidebate/)

À l’agora de Mila, à Montréal, le lundi 23 décembre 2019, de 18h30 à 20h30 (heure de l'Est), Gary Marcus et Yoshua Bengio ont débattu sur la meilleure voie à suivre pour l'IA. ZDNet a décrit l'événement organisé par MONTRÉAL.IA comme un [“événement historique”](https://www.zdnet.com/article/devils-in-the-details-in-bengio-marcus-ai-debate/). 5,225 billets ont été réservés pour l'événement en direct. [Compte-rendu du débat sur l'IA](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/).

Des **diapositives, vidéos, lectures** et autres sont disponibles sur la [page web](https://montrealartificialintelligence.com/aidebate/) du débat de **MONTRÉAL.IA**.

**MONTRÉAL.IA** est reconnaissante envers [Gary Marcus](http://garymarcus.com), [Yoshua Bengio](https://mila.quebec/en/yoshua-bengio/), [Mila - Institut Québécois d'Intelligence Artificielle](https://mila.quebec/) et envers l'[écosystème collaboratif de Montréal en matière d'IA](https://www.facebook.com/groups/MontrealAI/). Un remerciement spécial à [Sasha Lu](https://sashaluccioni.com).

[![100 pays et 1000 villes](../images/attendeescity.jpeg "100 pays et 1000 villes")](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/)

***

*(Cet événement est offert en ligne à une clientèle internationale en anglais)*
## **❖ Deep Reinforcement Learning with OpenAI Gym 101**

**Samedi, 13 février 2021, 10:00 AM – 11:30 AM** (heure de Montréal), le secrétariat général de __MONTRÉAL.IA__ présentera, avec autorité: "__*Deep Reinforcement Learning with OpenAI Gym 101*__" (en anglais).

<a href="https://reinforcementlearning101.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Acheter des billets sur Eventbrite</a>

[![Événement en ligne: 'Deep Reinforcement Learning with OpenAI Gym 101'](../images/RL101Webinarv19.jpg "Événement en ligne: 'Deep Reinforcement Learning with OpenAI Gym 101'")](https://reinforcementlearning101.eventbrite.ca)

<div id="eventbrite-widget-container-117727240345"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117727240345',
        iframeContainerId: 'eventbrite-widget-container-117727240345',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Langue:__ La présentation sera en __anglais__. *Le matériel de référence sera dans sa langue originale*.

> "**_L'intelligence est la partie informatique de la capacité à prédire et à contrôler un flux d'expériences._**" — Rich Sutton

__Lieu: L'événement a lieu en ligne.__ Il s'agit d'un webinaire en direct avec interaction avec et entre les étudiants. Les participants recevront des instructions sur la façon d'accéder à la diffusion en direct à *9:45 AM (heure de Montréal) samedi le 13 février 2021*.

***

## **❖ Conversation au coin du feu de MONTRÉAL.IA**

***

## **❖ Salon de MONTRÉAL.IA**

### _Rassemblement de gens sous le toit d'un hôte inspirant_

![Le salon MONTRÉAL.IA](../images/montrealiasalonv2.jpg "Le salon MONTRÉAL.IA s’inscrit dans la plus pure tradition des salons littéraires et philosophiques français du XV IIIème siècle.")

Le salon MONTRÉAL.IA s’inscrit dans la plus pure tradition des salons littéraires et philosophiques français du XV IIIème siècle. Débats et joutes d’idées en compagnie d’invités s’étant illustrés.

***

## **❖ SYMPOSIUM QUÉBEC IA**

### _Stimuler l’activité économique, la recherche et l’innovation en IA au Québec_

[![SYMPOSIUM QUÉBEC IA — Stimuler l’activité économique, la recherche et l’innovation en IA au Québec](../images/quebecaisymposium.png "SYMPOSIUM QUÉBEC IA — Stimuler l’activité économique, la recherche et l’innovation en IA au Québec")](https://quebecaisymposium.eventbrite.ca)

Le **SYMPOSIUM QUÉBEC IA**, administré par [MONTRÉAL.IA](http://www.montreal.ai) et [QUÉBEC.IA](http://www.quebec.ai), est un événement visant à stimuler l'activité économique, la recherche et l'innovation en intelligence artificielle au Québec et ainsi contribuer à la compétitivité et au rayonnement du Québec sur les plans national et international.

### Billets et réservation de groupe

__Réservation de groupe:__ secretariat@montreal.ai

__Billets:__ https://quebecaisymposium.eventbrite.ca

__Date et heure:__ __Jeudi le 10 juin 2021 | 9:30 à 20:30 (heure de Montréal)__.
__Location: Détails à annoncer__

__Site web:__ http://quebecaisymposium.com

***

*(Cet événement est offert en ligne à une clientèle internationale en anglais)*
## **❖ Chief AI Officers : Formation en IA pour les cadres**

### _Formation exécutive_

__*'Chief AI Officers: C-Level AI' : Une formation en IA pour les cadres*__ qui maximise les principes fondamentaux de l'intelligence artificielle au niveau de l'exécutif. Elle incite les décideurs à les mettre en pratique de manière stratégique dans les entreprises, les gouvernements et les institutions.

[!['Chief AI Officers: C-Level AI': Une formation en IA pour les cadres | Éducation exécutive](../images/ExecutiveEducation‎.jpg "'Chief AI Officers: C-Level AI': Une formation en IA pour les cadres | Éducation exécutive")](https://chiefaiofficers.eventbrite.ca)
> "**_Dans un moment de bouleversement technologique, le leadership compte._**" — Andrew Ng

Cette formation a été conçue pour atteindre une compréhension pointue des stratégies en [_IA transformatrice_](https://www.openphilanthropy.org/blog/some-background-our-views-regarding-advanced-artificial-intelligence#Sec1), donnant ainsi de nouvelles perspectives aux organisations étatiques, nationales et internationales.

### Profil des participants

__*'Chief AI Officers: C-Level AI' : Formation en IA pour les cadres*__  a été élaborée pour des: 

- Membres de conseil d'administration;
- Capitaines d'industrie;
- Directeurs généraux;
- Commandants; et
- Présidents ...

... qui souhaitent exalter de manière stratégique le pouvoir de l'intelligence artificielle.

<div id="eventbrite-widget-container-126693606989"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '126693606989',
        iframeContainerId: 'eventbrite-widget-container-126693606989',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Langue:__ La présentation sera en __anglais__.

***

*(Cet événement est offert en ligne à une clientèle internationale en anglais)*
## **❖ Intelligence artificielle 101: Webinaire (Artificial Intelligence 101 | International Webinar)**

### _Instituer une compréhension percutante de l'IA_

Englobant toutes les facettes de l'IA, le __Secrétariat général de MONTRÉAL.IA__ présente, avec autorité: "__*Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public*__".

__Lieu : Il s'agit d'un événement en ligne et en anglais.__

[![Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public](../images/academy1920cover_v0.jpg "Intelligence Artificielle 101 : Le premier survol de l'IA de classe mondiale pour le grand public")](https://artificialintelligence101.eventbrite.ca)

__L'IA ouvre un monde de nouvelles possibilités.__ Ce cours IA 101 explore les bases de l'intelligence artificielle dans le but de transmettre aux participant(e)s de puissants outils d'IA pour *apprendre*, *déployer* et *faire évoluer* l'IA.

> "**_(L'IA) comptera parmi nos plus grandes réalisations technologiques, et tout le monde mérite de jouer un rôle dans son élaboration._**" — Fei-Fei Li

<div id="eventbrite-widget-container-117895790483"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117895790483',
        iframeContainerId: 'eventbrite-widget-container-117895790483',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

### Billets et réservation de groupe

__Billets:__ https://artificialintelligence101.eventbrite.ca

__Réservation de groupe:__ secretariat@montreal.ai

__Date et heure:__ Samedi, 13 mars 2021 | De 10h00 AM à 11h30 AM HNE

__Langue:__ La présentation (webinaire) sera en __anglais__. *Le matériel de référence sera dans sa langue originale*.

__Lieu: L'événement a lieu en ligne.__ Il s'agit d'un webinaire en direct avec interaction avec et entre les étudiants. *__Les participants recevront des instructions sur la façon d'accéder au webinaire à 9h45 AM (HNE) le samedi 13 mars 2021__*.

** Le contenu de ce cours est destiné à votre usage personnel et ne doit pas être partagé ou diffusé. __En cas de force majeure, l'événement sera reporté à une date ultérieure.__

***

## **❖ Dîner des ambassadeurs de MONTRÉAL.IA**

***

## **❖ Orchestre de MONTRÉAL.IA**

### _Des symphonies pionnières légendaires_

![Orchestre de MONTRÉAL.IA: Des symphonies pionnières légendaires...](../images/AIConcert.jpg "Orchestre de MONTRÉAL.IA: Des symphonies pionnières légendaires...")

La forme la plus «pure» de créativité IA exprimée par la machine.

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ MONTREAL.AI MIXER _(RÉUNION de MONTRÉAL.IA)_**

### _Orchestrer des synergies..._

...  entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire.

[![MONTREAL.AI MIXER — Orchestrer les synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA à Montréal.](../images/MontrealAIMixerv2.jpg "MONTREAL.AI MIXER — Orchestrer les synergies entre les acteurs de l'IA, les entreprises, les gouvernements, les institutions et le milieu universitaire pour mobiliser l'écosystème de l'IA à Montréal.")](https://aimixer.eventbrite.ca)

### Billets et réservation de groupe

__Réservation de groupe :__ secretariat@montreal.ai

__Billets :__ https://aimixer.eventbrite.ca

__Date et heure :__ __Jeudi, 10 juin 2021 | 17:30 à 19:30 (heure de Montréal)__
__Lieu : Détails à annoncer__

***

## **❖ Vente aux enchères des beaux-arts de MONTRÉAL.IA**

### _Dévoilement d'un monde de secrets cachés..._

![La vente aux enchères des beaux-arts de MONTRÉAL.IA : un monde de secrets cachés à dévoiler...](../images/AITrillion1440.jpg "La vente aux enchères des beaux-arts de MONTRÉAL.IA : un monde de secrets cachés à dévoiler...")

Le 25 octobre 2018, [la première œuvre d'art en intelligence artificielle jamais vendue par la maison de ventes aux enchères Christie's a bouleversé les attentes, atteignant 432 500 $](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Aujourd'hui, la _Maison des Beaux-Arts de Montréal.IA_ présente : _La vente aux enchères des Beaux-Arts de Montréal.IA_, la **première vente aux enchères internationale consacrée à la quintessence des Beaux-Arts de l'IA**.

> "**_Les artistes qui créent avec AI ne suivront pas les tendances, ils les définiront._**" — Montréal.IA

Nous nous préparons pour la première vente aux enchères.

Les plus grands collectionneurs d'œuvres d'art pourront faire des offres à l'échelle internationale.

***

## **❖ Gala du Mérite philanthropique de MONTRÉAL.IA**

> "**_C'est le printemps pour l'IA, et nous prévoyons un long été._**" — Bill Braun, CIO de Chevron

✉️ __Courriel__ : info@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.montreal.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Montréal.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif*

#__IntelligenceArtificielle__ #__IntelligenceArtificielleMontreal__ #__MontrealIA__
