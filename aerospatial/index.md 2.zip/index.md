---
title: MONTRÉAL.IA | Intelligence artificielle Montréal
---
## MONTRÉAL.IA AÉROSPATIAL

__Une nouvelle ère de découvertes scientifiques surhumaines.__

[![Conscients que Montréal est un pôle mondial de l’industrie aérospatiale et un chef de file international en intelligence artificielle, nous avons fondé Montréal.IA Aérospatial. — Vincent Boucher, B. Sc. Physique, M.A. Analyse des politiques gouvernementales et M. Sc. Génie aérospatial (technologie spatiale), président-fondateur de Montréal.IA](../images/vincentboucher1440.jpg "Conscients que Montréal est un pôle mondial de l’industrie aérospatiale et un chef de file international en intelligence artificielle, nous avons fondé Montréal.IA Aérospatial. — Vincent Boucher, B. Sc. Physique, M.A. Analyse des politiques gouvernementales et M. Sc. Génie aérospatial (technologie spatiale), président-fondateur de Montréal.IA")](http://www.montreal.ai/vincentboucher.jpg)

> "**_Mon objectif est simple. C'est la compréhension complète de l'univers, pourquoi il est tel qu'il est et pourquoi il existe._**" — Stephen Hawking

__Un parcours légendaire | Comment tout a commencé —__ Découvrez la genèse de cet exceptionnel cheminement:
<p align="center">
[![Un parcours légendaire | Comment tout à commencé](../images/journalmontreal.jpg "Un parcours légendaire | Comment tout à commencé")](http://www.montreal.ai/mtl.pdf)
</p>
- [Vincent Boucher | ... un cerveau de l'aérospatial!](http://www.montreal.ai/mtl.pdf) — Le journal de Montréal
- [Étoiles filantes | Vincent Boucher](http://www.vincentboucher.com/agencespatialecanadienne.pdf) — Le bulletin des employés de l'Agence spatiale canadienne
- [Vincent Boucher | Un (jeune) homme d'exception](http://www.montreal.ai/lapresse.pdf) — Nathalie Petrowski, La Presse

![Feynman Diagrams | Quantum Electrodynamics](../images/FeynmanDiagramsQuantumElectrodynamics-QED.png "Feynman Diagrams | Quantum Electrodynamics")

## Montréal.IA Aérospatial: Vision globale

__IA + Aéronautique | Physique | Robotique__

__Vision :__ __*Être la pierre angulaire de l'industrie de l'IA aérospatiale.*__

> "**_Conscients que Montréal est un pôle mondial de l’industrie aérospatiale et un chef de file international en intelligence artificielle, nous avons fondé Montréal.IA Aérospatial._**" — Vincent Boucher, B. Sc. Physique, M.A. Analyse des politiques gouvernementales et M. Sc. Génie aérospatial (technologie spatiale), président-fondateur de Montréal.IA

__Montréal.IA Aérospatial__ a un statut particulier dans le portefolio __*de Montréal.IA*__.

![Montréal.IA Aérospatial: La pierre angulaire de l'industrie de l'IA aérospatiale](../images/consultingspace1920v0.jpg "Montréal.IA Aérospatial: La pierre angulaire de l'industrie de l'IA aérospatiale")

> "**_Ce que je ne peux pas créer, je ne peux pas le comprendre._**" — Richard Feynman

## Montréal.IA Aérospatial: Relever les défis les plus difficiles

__Nous sommes au seuil d'un changement technologique mondial.__

__Montréal.IA Aérospatial__ s'appuie sur l'*ingénierie aérospatiale*, l'*intelligence artificielle appliquée* et la recherche en *astrophysique* pour optimiser les __vols spatiaux__, l'efficacité des __satellites__, et l'__exploration spatiale__ à une échelle sans précédent.

Un nouveau modèle puissant pour un grand nombre de géants émergents de la superintelligence apparaît dans le paysage scientifique.

![Un trou noir supermassif | Crédit d'image: NASA/JPL-Caltech](../images/montrealaispace_shifting_coronas_around_black_holes_1280x720.jpg "Un trou noir supermassif | Crédit d'image: NASA/JPL-Caltech")

> "**_Toute technologie suffisamment avancée est indissociable de la magie._**" — Arthur C. Clarke

## Montréal.IA Aérospatial: Explorer les étoiles et l'Univers

Nous vivons une période de percées scientifiques incroyables. Les progrès à venir, au carrefour de l'*ingénierie aérospatiale* et de l'*intelligence artificielle*, ouvrent des perspectives extraordinaires pour l'avenir de l'Humanité.

{% pullquote [CSS class] %}
"**_Artificial Intelligence is about recognising patterns, Artificial Life is about creating patterns._**" — Mizuki Oka et al, #alife2018
{% endpullquote %}

__Montréal.IA Aérospatial__ croit à l'épanouissement de l’Humanité en misant sur la superintelligence pour explorer les étoiles: __*l’endroit où nous appartenons tous vraiment*__.

Avec plus d'ingéniosité, nous mettons en œuvre des agents IA très performants pour concevoir des algorithmes d'apprentissage en profondeur innovants comprenant notre __Univers__.

[![Notre vision: Être la pierre angulaire de l'industrie de l'IA aérospatiale.](../images/montrealaispaceneuralnetworks1920x1080.jpg "Notre vision: Être la pierre angulaire de l'industrie de l'IA aérospatiale.")](http://www.montreal.ai/mtl.pdf)

> "**_I think transfer learning is the key to general intelligence. And I think the key to doing transfer learning will be the acquisition of conceptual knowledge that is abstracted away from perceptual details of where you learned it from._**" — Demis Hassabis

Les agents IA surhumains de __Montréal.IA__ peuvent tirer des leçons des enseignements par l’expérience, simuler des mondes et orchestrer des méta-solutions.

__Montréal.IA Aérospatial__ offre une nouvelle ère globale de prouesses techniques percutantes à un niveau très élevé.

> "**_Bien sûr, les physiciens des particules ont été parmi les premiers à comprendre que la nature est compositionnelle._**" — Yann LeCun

### Références

- [Why does deep and cheap learning work so well?](https://arxiv.org/abs/1608.08225) — Henry W. Lin, Max Tegmark, David Rolnick
- [Introduction to astroML: Machine Learning for Astrophysics](https://arxiv.org/pdf/1411.5039.pdf) — Jacob VanderPlas, Andrew J. Connolly, Zˇeljko Ivezic ́, Alex Gray
- [CosmoFlow: Using Deep Learning to Learn the Universe at Scale](https://arxiv.org/pdf/1808.04728.pdf) — Mathuriya et al.
- [Bayesian Deep Learning for Exoplanet Atmospheric Retrieval](https://arxiv.org/abs/1811.03390) — Frank Soboczenski, Michael D. Himes, Molly D. O'Beirne, Simone Zorzan, Atilim Gunes Baydin, Adam D. Cobb, Daniel Angerhausen, Giada N. Arney, Shawn D. Domagal-Goldman
- [Galaxy morphology prediction using capsule networks](https://arxiv.org/abs/1809.08377) — Katebi et al.
- [Machine Learning for Physics and the Physics of Learning](http://www.ipam.ucla.edu/programs/long-programs/machine-learning-for-physics-and-the-physics-of-learning/) — Steve Brunton, Cecilia Clementi, Yann LeCun, Marina Meila, Frank Noe, Francesco Paesani
- [MINERVA-II1: Successful image capture, landing on Ryugu and hop!](http://www.hayabusa2.jaxa.jp/en/topics/20180922e/) — JAXA | Japan Aerospace Exploration Agency
- [Restricted Boltzmann Machines for Collaborative Filtering](https://www.cs.toronto.edu/~rsalakhu/papers/rbmcf.pdf) — Ruslan Salakhutdinov, Andriy Mnih, Geoffrey Hinton
- [A Practical Guide to Training Restricted Boltzmann Machines](https://www.cs.toronto.edu/~hinton/absps/guideTR.pdf) — Geoffrey Hinton
- [GAIA DATA RELEASE 1](https://www.cosmos.esa.int/web/gaia/data-release-1) — European Space Agency
- [Evolved Virtual Creatures, Evolution Simulation, 1994](https://youtu.be/JBgG_VSP7f8) — Karl Sims
- [PHYSICS | MACHINE LEARNING - Recent papers combining the fields of physics and machine learning](https://physicsml.github.io/pages/papers.html) — physicsml
- [AI Model Could Help Robots Navigate on the Moon and Mars Without GPS](https://news.developer.nvidia.com/ai-model-could-help-robots-navigate-on-the-moon-and-mars-without-gps/) — NVIDIA
- Machine Learning and Likelihood-Free Inference in Particle Physics [Slides](https://figshare.com/articles/NIPS_2016_Keynote_Machine_Learning_Likelihood_Free_Inference_in_Particle_Physics/4291565/1) | [Video](https://channel9.msdn.com/Events/Neural-Information-Processing-Systems-Conference/Neural-Information-Processing-Systems-Conference-NIPS-2016/Machine-Learning-and-Likelihood-Free-Inference-in-Particle-Physics) — Kyle Cranmer
- [Enabling Dark Energy Science with Deep Generative Models of Galaxy Images](https://arxiv.org/abs/1609.05796) — Siamak Ravanbakhsh, Francois Lanusse, Rachel Mandelbaum, Jeff Schneider, Barnabas Poczos
- [Unity and DeepMind to Advance AI Research Using Virtual Worlds](https://www.businesswire.com/news/home/20180926005180/en/Unity-DeepMind-Advance-AI-Research-Virtual-Worlds) — Business Wire
- [A look at deep learning for science](https://www.oreilly.com/ideas/a-look-at-deep-learning-for-science) — Prabhat
- [Searching for Exotic Particles in High-Energy Physics with Deep Learning](https://arxiv.org/abs/1402.4735) — Pierre Baldi, Peter Sadowski, Daniel Whiteson
- [Estimating Cosmological Parameters from the Dark Matter Distribution](https://arxiv.org/abs/1711.02033) — Siamak Ravanbakhsh, Junier Oliva, Sebastien Fromenteau, Layne C. Price, Shirley Ho, Jeff Schneider, Barnabas Poczos

## "MONTEZ DANS LA FUSÉE": Rejoignez Montréal.IA Aérospatial!

Réunissant des contributions de chercheurs reconnus comme étant les principales autorités dans leur domaine, __Montréal.IA Aérospatial__ est en avance sur une tendance qui influencera profondément l'avenir de l'Humanité.

[![Notre vision: Être la pierre angulaire de l'industrie de l'IA aérospatiale.](../images/montrealaispace1280x720.jpg "Notre vision: Être la pierre angulaire de l'industrie de l'IA aérospatiale.")](http://www.montreal.ai/mtl.pdf)

__Montréal.IA Aérospatial__ est à la recherche d'__*associés*__ et de __*partenaires*__ prospères: *capitaines d'industrie*, *philanthropes*, *entrepreneurs en technologie de pointe*, *financiers* and *érudits de haut vol* pour se joindre à notre équipe dans cette tâche aux proportions historiques.

✉️ __Courriel__ : info@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.montreal.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Montréal.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif*

#__IntelligenceArtificielle__ #__IntelligenceArtificielleMontreal__ #__MontrealIA__
