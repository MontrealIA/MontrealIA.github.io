---
title: Montréal Artificial Intelligence
---
## Montréal.AI Web — The Dawn of Artificial Intelligence

__Artificial Intelligence for the Web :__ Converting AI Research into Commercial Successes.

__At the forefront of AI__, deploying superhuman agents that can _learn from experience_ in the browser unlocks new powerful possibilities to apply AI in ways we never thought of! E.g., on a mobile device, the autonomous agent can leverage sensor data (i.e.: gyroscope or accelerometer) and take actions. True understanding comes from agents that learn by "seeing" how they affect the world.

All data stays on the client, making AI agents in the browser useful for _privacy preserving applications_.

![Montréal.AI Web — Artificial Intelligence for the Web](../images/MontrealAIWeb1080x1920.jpg "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

> " _Artificial Intelligence is about recognising patterns, Artificial Life is about creating patterns._ "
<p align="right">— Mizuki Oka et al, #alife2018</p>

### A Proof of Concept : Getting Alexa to Respond to Sign Language

Using _TensorFlow_ to make an _Amazon Echo_ respond to sign language, by M. A. Singh :

<p align="center">
![Getting Alexa to Respond to Sign Language Using a Webcam and TensorFlow.js](../images/AlexaSignLanguage.gif "Getting Alexa to Respond to Sign Language Using a Webcam and TensorFlow.js")
</p>

- [Blog Post by ](https://medium.com/tensorflow/getting-alexa-to-respond-to-sign-language-using-your-webcam-and-tensorflow-js-735ccc1e6d3f) by M. A. Singh
- [Code for the Proof of Concept on GitHub](https://github.com/shekit/alexa-sign-language-translator)

## Advanced and Impactful Open-Source Technologies 

Bringing contributions by scholars recognized as the foremost authorities in their fields, Montréal Artificial Intelligence is ahead of trends that will profoundly influence the future of Humanity.

Cutting edge open-source technologies proudly used :

### 1. TensorFlow.js

__Training and Deploying ML Models in the Browser__

TensorFlow.js uses flexible and intuitive APIs to build and train models from scratch using a low-level JavaScript linear algebra library or a high-level layers API. The TensorFlow.js model converters allows running pre-existing TensorFlow models right in the browser or under Node.js. Pre-existing ML models can be retrained using sensor data connected to the browser, or other client-side data. Three development workflows :

  * Importing an existing, pre-trained model for inference ;

  * Re-training an imported model quickly (transfer learning) with only a small amount of data ; and
  
  * Authoring (define, train, and run) models directly in the browser.

![An overview of TensorFlow.js APIs. TensorFlow.js is powered by WebGL and supports importing TensorFlow SavedModels and Keras models](../images/TensorFlow_js_API.png "An overview of TensorFlow.js APIs")

TensorFlow.js AI agents can be trained using _reinforcement learning_, _neuroevolution_, or other _machine learning_ methods. There’s no need to install anything. Just open a webpage, and your AI Agent is ready to run.

__References__ :

- [TensorFlow.js](https://js.tensorflow.org)
- [TensorFlow dev summit](https://www.youtube.com/watch?v=YB-kfeNIPCE) Official TensorFlow.js Launch
- [Introducing TensorFlow.js](https://medium.com/tensorflow/introducing-tensorflow-js-machine-learning-in-javascript-bf3eab376db) by Josh Gordon and Sara Robinson
- [Deep Learning in JS - Ashi Krishnan - JSConf EU 2018](https://www.youtube.com/watch?v=SV-cgdobtTA)
- [TensorFlow.js Gallery](https://github.com/tensorflow/tfjs/blob/master/GALLERY.md)

### 2. Reinforcement Learning

__Going Beyond Input-Output Pattern Recognition__

In the past few years deep reinforcement learning started achieving state-of-the-art results. 

> " _Reinforcement learning (RL) is the subfield of machine learning concerned with decision making and motor control. It studies how an agent can learn how to achieve goals in a complex, uncertain environment._ " — OpenAI

At the bleeding edge of AI, autonomous agents can learn from experience, simulate worlds and orchestrate meta-solutions. Here's an inspiring example of a high-quality implementation of a reinforcement learning algorithm :

![OpenAI Five’s Networks Model Structure](../images/networkarchitecture1440.jpg "OpenAI Five’s Networks Model Structure")

Powerful and useful application domains : 

<p align="center"><b><i>Dialogue, Healthcare, Management, Robotics, Smart Grid, Supply Chains, etc.</i></b></p>

> " _Self-Play is Automated Knowledge Creation._ " — Carlos E. Perez

__References__ :

- [OpenAI Gym](https://github.com/openai/gym) by OpenAI
- [OpenAI Baselines](https://github.com/openai/baselines) by OpenAI
- [AlphaGo Zero: Learning from scratch](https://deepmind.com/blog/alphago-zero-learning-scratch/) by DeepMind
- [A Visual Guide to Evolution Strategies](http://blog.otoro.net/2017/10/29/visual-evolution-strategies/) by David Ha
- [OpenAI Five](https://blog.openai.com/openai-five/) by OpenAI

### 3. TensorFlow Hub

__Reusing Machine Learning Modules__

TensorFlow Hub is a library for the publication, discovery, and consumption of reusable parts of machine learning models. A module is a self-contained piece of a TensorFlow graph, along with its weights and assets, that can be reused across different tasks in a process known as transfer learning. Transfer learning can:

  * Train a model with a smaller dataset ;
  
  * Improve generalization: and
  
  * Speed up training.

![“Ingredients” of a machine learning model that can be packaged and shared through TensorFlow Hub. In a sense, sharing a pre-trained model also shares the compute time and dataset used to develop the model, in addition to architecture itself](../images/TensorFlow_Hub.png "“Ingredients” of a machine learning model that can be packaged and shared through TensorFlow Hub")

> " _I think transfer learning is the key to general intelligence. And I think the key to doing transfer learning will be the acquisition of conceptual knowledge that is abstracted away from perceptual details of where you learned it from._ " — Demis Hassabis

- [TensorFlow Hub](https://www.tensorflow.org/hub/)
- [Introducing TensorFlow Hub](https://medium.com/tensorflow/introducing-tensorflow-hub-a-library-for-reusable-machine-learning-modules-in-tensorflow-cdee41fa18f9) by Josh Gordon

## Transform your Web Site with an AI Agent

__Fully-fledged AI systems can achieve serious revenue!__ 

Montréal Artificial Intelligence helps to transform Web sites for the age of artificial intelligence by developing machine learning agents in the browser that achieves goal-oriented behavior.

__Demos :__ 

  1. __*Solving the cart-pole control problem in the browser using the policy-gradient method*__

  * Live demo : https://storage.googleapis.com/tfjs-examples/cart-pole/dist/index.html
  * Code : https://github.com/tensorflow/tfjs-examples/tree/master/cart-pole

  2. __*Predicting balls and strikes using TensorFlow.js*__
<p align="center">
![Montréal.AI Web — Artificial Intelligence for the Web](../images/PredictingBallsStrikes.gif "Montréal.AI Web : Deploying Machine Learning Models in the Browser")
</p>
  * Blog : https://medium.com/tensorflow/predicting-balls-and-strikes-using-tensorflow-js-2acf1d7a447c

  3. __*Animation with CPPNs and TensorFlow.js, an @observablehq notebook by Emily Reif*__

  * @observablehq notebook by Emily Reif : https://beta.observablehq.com/@emilyreif/animation-with-cppns

  4. __*Move Mirror: An AI Experiment with Pose Estimation in the Browser using TensorFlow.js*__
<p align="center">
![Montréal.AI Web — Artificial Intelligence for the Web](../images/MoveMirror.gif "Montréal.AI Web : Deploying Machine Learning Models in the Browser")
</p>
  * By Jane Friedhoff and Irene Alvarado : https://medium.com/tensorflow/move-mirror-an-ai-experiment-with-pose-estimation-in-the-browser-using-tensorflow-js-2f7b769f9b23

  5. __*L1: Tensor Studio — An in-browser live-programming environment by Milan Lajtoš*__

![Montréal.AI Web — Artificial Intelligence for the Web](../images/L1TensorStudio.png "Montréal.AI Web : Deploying Machine Learning Models in the Browser")

  * Live demo : https://mlajtos.github.io/L1/latest/ 
  * Github : https://github.com/mlajtos/L1

__References__ :

- [Unity ML-Agents Toolkit](https://github.com/Unity-Technologies/ml-agents) by Unity
- [A Brief Survey of Deep Reinforcement Learning](https://arxiv.org/abs/1708.05866) Arulkumaran et al.

> " _Nothing is more powerful than an idea whose time has come._ " — Victor Hugo

Montréal.AI is offering a new world age of impactful technical prowesses on an unprecedented scale.

## To order your AI Agent :

✉️ __Email Us__ : info@montreal.ai

#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealArtificialIntelligence__
