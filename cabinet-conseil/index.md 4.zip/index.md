---
title: MONTRÉAL.IA | Intelligence Artificielle Montréal
---
## Le Cabinet-Conseil Montréal.IA

![Le Cabinet-Conseil Montréal.IA](../images/chiefaiofficers500x1500_v0.jpg "Le Cabinet-Conseil Montréal.IA : Experts en apprentissage profond « deep learning »")

## Experts en apprentissage profond « deep learning »

__MONTRÉAL.IA | Intelligence Artificielle Montréal__ compte sur le recrutement, le développement et la formation de femmes et d’hommes possédant les aptitudes et les compétences nécessaires pour orchestrer des percées significatives pour le __*Fortune 500*__, les __*gouvernements*__ et les __*partenaires institutionnels*__. 

Considérant que l'embauche d'experts en apprentissage profond est très compliquée puisque vous êtes en compétition pour les meilleurs talents avec __*Google*__, __*Facebook*__, __*Microsoft*__, etc., le __Cabinet-Conseil Montréal.IA__ offre des services de consultation pour confectionner des algorithmes d'intelligence artificielle sur mesure.

## L'Atelier Montréal.IA

L' __Atelier Montréal.IA__ crée et déploie des modèles en apprentissage profond ainsi que des __*systèmes d'intelligence artificielle*__ à part entière intégrant l'apprentissage par transfert et par renforcement.

![Modèle en apprentissage profond](../images/nn.jpg "Modèle en apprentissage profond")

> “_L'année dernière, le coût d'un expert en apprentissage profond « deep learning » de classe mondiale était à peu près le même que celui d'un joueur quart-arrière de la NFL. Le coût de ce talent est assez remarquable._” — Peter Lee, chef de la recherche chez Microsoft

__Références__ :

  * '*Million-dollar babies*' - http://www.economist.com/news/business/21695908-silicon-valley-fights-talent-universities-struggle-hold-their
  * '*The Battle for Top AI Talent Only Gets Tougher From Here*' - https://www.wired.com/2017/03/intel-just-jumped-fierce-competition-ai-talent/
  * '*A.I. Researchers Are Making More Than $1 Million, Even at a Nonprofit*' - https://www.nytimes.com/2018/04/19/technology/artificial-intelligence-salaries-openai.html

![Intelligence Artificielle Montréal | L'Atelier Montréal.IA](../images/13Feb2011ai360_1920.jpg "Intelligence Artificielle Montréal | L'Atelier Montréal.IA")

✉️ __Courriel__ : info@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Maison-mère__ : 350, rue Prince-Arthur Ouest, suite 2105, Montréal, Qc H2X 3R4 **Bureau administratif*

#__AIFirst__ #__IntelligenceArtificielleMontreal__ #__MontrealAI__
