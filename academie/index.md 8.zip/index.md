---
title: MONTRÉAL.IA | Intelligence Artificielle Montréal
---
## L’Académie de Montréal.IA

__INTELLIGENCE ARTIFICIELLE 101 | Signé Montréal.IA__

![IA 101: Le premier survol complet de l’IA destiné au grand public](../images/intelligenceartificielle101v960x1920.jpg "IA 101: Le premier survol complet de l’IA destiné au grand public")

<a href="https://www.eventbrite.ca/e/billets-intelligence-artificielle-101-53392102215?ref=ebtn" target="_blank"><img src="https://www.eventbrite.ca/custombutton?eid=53392102215" alt="Eventbrite - Intelligence artificielle 101" /></a>

### IA 101: Le premier survol complet de l’IA destiné au grand public

__Un cours de 75 minutes pratique et bien conçu!__

{% blockquote Andrew Ng https://www.quora.com/I-want-to-pursue-machine-learning-as-a-career-but-not-sure-if-I-am-qualified-How-can-I-test-myself/answer/Andrew-Ng I want to pursue machine learning as a career but not sure if I am qualified... %}
You are qualified for a career in machine learning!
{% endblockquote %}

Réunissant toutes les facettes de l'IA, le __secrétariat général de MONTRÉAL.IA__ introduit: "__*Intelligence Artificielle 101 : Un survol complet sur l’IA destiné au grand public*__".

__PUISSANT ET UTILE.__ Ce cours est conçu pour offrir à tous l’état d’esprit, les compétences et les outils nécessaires pour percevoir l’intelligence artificielle d’un nouveau point de vue stimulant:

— Des découvertes et des connaissances scientifiques de pointe;
— Les meilleurs codes et implémentations "open source" ;
— L’impulsion qui anime l’intelligence artificielle d’aujourd’hui.

> "**_In life, you need forcing functions. You never know what you’re capable of until you have no choice but go and do it. Excessive comfort leads to unrealized potential._**" — François Chollet

<div style="width:100%; text-align:left;"><iframe src="https://eventbrite.ca/tickets-external?eid=53392102215&ref=etckt" frameborder="0" height="530" width="100%" vspace="0" hspace="0" marginheight="5" marginwidth="5" scrolling="auto" allowtransparency="true"></iframe><div style="font-family:Helvetica, Arial; font-size:12px; padding:10px 0 5px; margin:2px; width:100%; text-align:left;" ><a class="powered-by-eb" style="color: #ADB0B6; text-decoration: none;" target="_blank" href="https://www.eventbrite.ca/">Powered by Eventbrite</a></div></div>

__Langage:__ La présentation orale sera en français et offrira des *diapositives dans leur langue originale anglaise*.
__Programme:__ http://montreal.ai/academy.pdf
__Lieu: Montréal (Québec), Canada.__

## Une liste de codes et implémentations en "open source" confectionnée à titre gracieux:

__Montréal.IA__ est la plus grande communauté IA au Canada. **_Rejoignez-nous et apprenez tout de l'IA!_** https://www.facebook.com/groups/MontrealAI/ !

[![Une liste de codes et implémentations en "open source" confectionnée à titre gracieux](../images/ai101MontrealIA1440x1440v1.jpg "Une liste de codes et implémentations en open source confectionnée à titre gracieux")](http://montreal.ai/MontrealAI101.jpg)

__*Cette section est présentée dans sa langue originale anglaise.__

> "**_The best way to predict the future is to invent it._**" — Alan Kay

### 0. Getting Started

Today’s artificial intelligence is powerful, useful and accessible to all.

Tinker with Neural Networks : [Neural Network Playground](http://playground.tensorflow.org/) — TensorFlow

__On a Local Machine__
[Install](https://www.anaconda.com/download/) Anaconda and Launch ‘*Anaconda Navigator*’ 
Update Jupyterlab and Launch the Application Under Notebook, Click on ‘*Python 3*’
- [JupyterLab is Ready for Users](https://blog.jupyter.org/jupyterlab-is-ready-for-users-5a6f039b8906) — Project Jupyter

__In the Cloud__
- [Colab: An easy way to learn and use TensorFlow](https://medium.com/tensorflow/colab-an-easy-way-to-learn-and-use-tensorflow-d74d1686e309) — TensorFlow
- [Access free GPU compute via Colab](https://colab.research.google.com/notebooks/welcome.ipynb) — TensorFlow
- [Open in Colab — Open a Github-hosted notebook in Google Colab](https://chrome.google.com/webstore/detail/open-in-colab/iogfkhleblhcpcekbiedikdehleodpjo) — colab-team
- [TensorFlow Blog](https://medium.com/tensorflow) — TensorFlow

__In the Browser__
- [TensorFlow dev summit](https://www.youtube.com/watch?v=YB-kfeNIPCE) Official TensorFlow.js Launch
- [Introducing TensorFlow.js: Machine Learning in Javascript](https://medium.com/tensorflow/introducing-tensorflow-js-machine-learning-in-javascript-bf3eab376db) —  Josh Gordon, Sara Robinson
- [TensorFlow.js](https://js.tensorflow.org/) — TensorFlow

__Preliminary Readings__
- [Deep Learning](https://www.cs.toronto.edu/~hinton/absps/NatureDeepReview.pdf) — Yann LeCun, Yoshua Bengio, Geoffrey Hinton
- [The WIRED Guide to artificial intelligence](https://www.wired.com/story/guide-artificial-intelligence/) — WIRED
- [How to teach yourself hard things](https://jvns.ca/blog/2018/09/01/learning-skills-you-can-practice/) — Julia Evans
- [Learn X in Y minutes (Where X=python3)](https://learnxinyminutes.com/docs/python3/) — Louie Dinh
- [The Matrix Calculus You Need For Deep Learning](http://parrt.cs.usfca.edu/doc/matrix-calculus/index.html) — Terence Parr, Jeremy Howard
- [Introduction to the math of backprop](https://github.com/DebPanigrahi/Machine-Learning/blob/master/back_prop.ipynb) — Deb Panigrahi
- [Introduction to Applied Linear Algebra – Vectors, Matrices, and Least Squares](https://web.stanford.edu/~boyd/vmls/) — Stephen Boyd and Lieven Vandenberghe, Cambridge University Press
- ["A birds-eye view of optimization algorithms"](http://fa.bianp.net/teaching/2018/eecs227at/) — Fabian Pedregosa
- [Dive into Deep Learning](http://en.diveintodeeplearning.org) — Aston Zhang, Zack C. Lipton, Mu Li, Alex J. Smola
- [How to visualize decision trees](http://explained.ai/decision-tree-viz/index.html) — Terence Parr, Prince Grover
- [Machine Learning for Visualization](https://medium.com/@enjalot/machine-learning-for-visualization-927a9dff1cab) — Ian Johnson
- [Scipy Lecture Notes](http://www.scipy-lectures.org) — Scipy
- [Interview with The Youngest Kaggle Grandmaster: Mikel Bober-Irizar (anokas)](https://hackernoon.com/interview-with-the-youngest-kaggle-grandmaster-mikel-bober-irizar-anokas-17dfd2461070?fbclid=IwAR1YJ1G_PgeiYNmdgBumWo-RqAfOT6JuZsitnjEexFXJHVumj15I_Os8FIM) — Sanyam Bhutani, Hacker Noon
- [Cutting-Edge Face Recognition is Complicated. These Spreadsheets Make it Easier.](https://towardsdatascience.com/cutting-edge-face-recognition-is-complicated-these-spreadsheets-make-it-easier-e7864dbf0e1a) — Dave Smith
- [Competitive Programmer’s Handbook](https://cses.fi/book/book.pdf) — Antti Laaksonen
- [Machine Learning from scratch!](https://github.com/anhquan0412/basic_model_scratch) — Quan Tran
- [Rules of Machine Learning: Best Practices for ML Engineering](http://martin.zinkevich.org/rules_of_ml/rules_of_ml.pdf) — Martin Zinkevich
- [A Neural Network in 11 lines of Python](http://iamtrask.github.io/2015/07/12/basic-python-network/) — iamtrask
- [Bias-Variance Decomposition](https://github.com/rasbt/mlxtend/blob/master/docs/sources/user_guide/evaluate/bias_variance_decomp.ipynb) — Sebastian Raschka
- SpaceSheet: Interactive Latent Space Exploration through a Spreadsheet Interface [Paper](https://nips2018creativity.github.io/doc/spacesheets.pdf) | [Demo](https://vusd.github.io/spacesheet/) | [Tool](http://bryanlohjy.gitlab.io/spacesheet/fonts.html) — Bryan Loh, Tom White
- [On intelligence: its creation and understanding](https://hai.stanford.edu/news/the_intertwined_quest_for_understanding_biological_intelligence_and_creating_artificial_intelligence/) — Surya Ganguli
- [Introduction to Artificial Intelligence, ULiège, Fall 2018.](https://github.com/glouppe/info8006-introduction-to-ai) — Gilles Louppe
- [Deep Learning cheatsheets for Stanford's CS 230](https://github.com/afshinea/stanford-cs-230-deep-learning) — Afshine Amidi, Shervine Amidi 
- [Machine Learning From Scratch](https://github.com/eriklindernoren/ML-From-Scratch) — Erik Linder-Norén
- [A Beginner's Guide to the Mathematics of Neural Networks](http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.161.3556&rep=rep1&type=pdf) — A.C.C. Coolen

[![Artificial Intelligence 101: The First World-Class Overview of AI for the General Public](../images/academy1920cover_v0.jpg "Artificial Intelligence 101: The First World-Class Overview of AI for the General Public")](http://montreal.ai/academy.pdf)

### 1. Deep Learning

> "**_DL is essentially a new style of programming--"differentiable programming"--and the field is trying to work out the reusable constructs in this style. We have some: convolution, pooling, LSTM, GAN, VAE, memory units, routing units, etc._**" — Thomas G. Dietterich

#### 1.1 Neural Networks

> "**_Neural networks" are a sad misnomer. They're neither neural nor even networks. They're chains of differentiable, parameterized geometric functions,  trained with gradient descent (with gradients obtained via the chain rule). A small set of highschool-level ideas put together._**" — François Chollet

- [AI Playbook](http://aiplaybook.a16z.com) — Andreessen Horowitz
- [Clear Explanations of Machine Learning](https://distill.pub) — Distill
- [Deep Learning Book](http://www.deeplearningbook.org) — Ian Goodfellow, Yoshua Bengio, Aaron Courville
- [Neural Networks and Deep Learning](http://neuralnetworksanddeeplearning.com) — Michael Nielsen
- [Deep Learning](https://www.udacity.com/course/deep-learning--ud730) — Vincent Vanhoucke | Google
- [TensorSpace: Neural network 3D visualization framework](https://tensorspace.org) —TensorSpace
- [A Complete Implementation of a Toy Neural Network](http://cs231n.github.io/neural-networks-case-study/) — Stanford CS class CS231n
- [Neural networks: training with backpropagation](https://www.jeremyjordan.me/neural-networks-training/) — Jeremy Jordan
- [Introduction to Machine Learning for Coders](http://course.fast.ai/ml) — Jeremy Howard
- [Machine Learning Yearning](https://d2wvfoqc9gyqzf.cloudfront.net/content/uploads/2018/09/Ng-MLY01-13.pdf) — Andrew Ng
- [Effective TensorFlow for Non-Experts](https://youtu.be/5DknTFbcGVM) — Google Developers
- [A curated collection of inspirational AI-powered JavaScript apps](https://aijs.rocks) — Elle Haproff, Asim Hussain, Osama Jandali
- [Pytorch Implementation of Neural Processes](https://chrisorm.github.io/NGP.html) — Chris Ormandy
- [A Few Unusual Autoencoders](https://colinraffel.com/talks/vector2018few.pdf) — Colin Raffel
- [Pytorch implementation of JointVAE, a framework for disentangling continuous and discrete factors of variation ](https://github.com/Schlumberger/joint-vae) — Schlumberger Software Technology
- [A New TensorFlow Hub Web Experience](https://medium.com/tensorflow/a-new-tensorflow-hub-web-experience-c804496e99f3) — André Susano Pinto, Clemens Mewald
- [Approximate Fisher Information Matrix to Characterise the Training of Deep Neural Networks](https://arxiv.org/abs/1810.06767) — Zhibin Liao, Tom Drummond, Ian Reid, Gustavo Carneiro
- [Building Web App for Computer Vision Model & Deploying to Production in 10 Minutes*: A Detailed Guide](https://towardsdatascience.com/building-web-app-for-computer-vision-model-deploying-to-production-in-10-minutes-a-detailed-ec6ac52ec7e4) — Pankaj Mathur
- [Measuring the Effects of Data Parallelism on Neural Network Training](https://arxiv.org/abs/1811.03600) — Christopher J. Shallue, Jaehoon Lee, Joe Antognini, Jascha Sohl-Dickstein, Roy Frostig, George E. Dahl
- [Avito Demand Prediction Challenge : Kaggle winner explains how to combine categorical, numerical, image and text features into a single NN that gets you into top 10 without stacking](https://www.kaggle.com/c/avito-demand-prediction/discussion/59880) — Little Boat
- fast.ai | Making neural nets uncool again [Intro Machine Learning](http://course.fast.ai/ml) | [Practical Deep Learning](http://course.fast.ai) | [Cutting Edge Deep Learning](http://course.fast.ai/part2.html) | [Computational Linear Algebra](https://github.com/fastai/numerical-linear-algebra) —  Jeremy Howard, Rachel Thomas | Fast.AI

> "**_I feel like a significant percentage of Deep Learning breakthroughs ask the question "how can I reuse weights in multiple places?"
-- Recurrent (LSTM) layers reuse for multiple timesteps
-- Convolutional layers reuse in multiple locations. 
-- Capsules reuse across orientation._**" — Trask

#### 1.2 Recurrent Neural Networks

- [Understanding LSTM Networks](http://colah.github.io/posts/2015-08-Understanding-LSTMs/) — Christopher Olah
- [Attention and Augmented RNN](https://distill.pub/2016/augmented-rnns/) — Olah & Carter, 2016
- [Computer, respond to this email](https://ai.googleblog.com/2015/11/computer-respond-to-this-email.html) — Post by Greg Corrado
- [Reversible Recurrent Neural Networks](https://arxiv.org/abs/1810.10999) — Matthew MacKay, Paul Vicol, Jimmy Ba, Roger Grosse
- Recurrent Relational Networks [Blog](https://rasmusbergpalm.github.io/recurrent-relational-networks/) | [arXiv](https://arxiv.org/pdf/1711.08028.pdf) | [Code](https://github.com/rasmusbergpalm/recurrent-relational-networks) — Rasmus Berg Palm, Ulrich Paquet, Ole Winther
- Massive Exploration of Neural Machine Translation Architectures [arXiv](https://arxiv.org/pdf/1703.03906.pdf) | [Docs](https://google.github.io/seq2seq/) | [Code](https://github.com/google/seq2seq) — Denny Britz, Anna Goldie, Minh-Thang Luong, Quoc Le
- A TensorFlow implementation of : "Hybrid computing using a neural network with dynamic external memory" [GitHub](https://github.com/deepmind/dnc) — Alex Graves, Greg Wayne, Malcolm Reynolds, Tim Harley, Ivo Danihelka, Agnieszka Grabska-Barwińska, Sergio Gómez Colmenarejo, Edward Grefenstette, Tiago Ramalho, John Agapiou, Adrià Puigdomènech Badia, Karl Moritz Hermann, Yori Zwols, Georg Ostrovski, Adam Cain, Helen King, Christopher Summerfield, Phil Blunsom, Koray Kavukcuoglu & Demis Hassabis

#### 1.3 Convolution Neural Network

> "**_I admire the elegance of your method of computation; it must be nice to ride through these fields upon the horse of true mathematics while the like of us have to make our way laboriously on foot._**" — A. Einstein

- [CNN Is All You Need](https://arxiv.org/abs/1712.09662) — Qiming Chen, Ren Wu
- [Feature Visualization](https://distill.pub/2017/feature-visualization/) — Chris Olah, Alexander Mordvintsev, Ludwig Schubert
- [Understanding Neural Networks Through Deep Visualization](http://yosinski.com/deepvis) — Jason Yosinski, Jeff Clune, Anh Nguyen, Thomas Fuchs, and Hod Lipson
- [MedicalTorch](https://medicaltorch.readthedocs.io/en/stable/) — Christian S. Perone
- [Deep Learning for Generic Object Detection: A Survey](https://arxiv.org/abs/1809.02165v1) — Li Liu, Wanli Ouyang, Xiaogang Wang, Paul Fieguth, Jie Chen, Xinwang Liu, Matti Pietikäinen
- [The Building Blocks of Interpretability](https://distill.pub/2018/building-blocks/) — Chris Olah, Arvind Satyanarayan, Ian Johnson, Shan Carter, Ludwig Schubert, Katherine Ye, Alexander Mordvintsev
- [Detectron : State-of-the-art Object Detection](https://github.com/facebookresearch/Detectron) — Ross Girshick and Ilija Radosavovic and Georgia Gkioxari and Piotr Doll\'{a}r and Kaiming He
- [YOLOv3: An Incremental Improvement](https://pjreddie.com/media/files/papers/YOLOv3.pdf) | [WebSite](https://pjreddie.com/darknet/yolo/) | [YouTube](https://youtu.be/MPU2HistivI) — Joseph Redmon, Ali Farhadi
- [From Recognition to Cognition: Visual Commonsense Reasoning](https://arxiv.org/abs/1811.10830) — Rowan Zellers, Yonatan Bisk, Ali Farhadi, Yejin Choi
- [AdVis.js : Exploring Fast Gradient Sign Method](http://jlin.xyz/advis/) — Jason Lin, Dilara Soylu
- [Machine Learning for Artists](http://ml4a.github.io/ml4a/) | [This is how convolution works](http://ml4a.github.io/demos/convolution/) — Machine Learning for Artists
- [Deep Painterly Harmonization](https://sgugger.github.io/deep-painterly-harmonization.html#deep-painterly-harmonization) | [Notebook](https://github.com/sgugger/Deep-Learning/blob/master/DeepPainterlyHarmonization.ipynb) — Sylvain Gugger
- [A Deep Learning based magnifying glass](https://medium.com/idealo-tech-blog/a-deep-learning-based-magnifying-glass-dae1f565c359) — Francesco Cardinale
- [How Convolutional Neural Networks Work](https://youtu.be/FmpDIaiMIeA) — Brandon Rohrer

#### 1.4 Capsules

- [Dynamic Routing Between Capsules](https://arxiv.org/abs/1710.09829) — Sara Sabour, Nicholas Frosst, Geoffrey E Hinton
- [Capsule Networks (CapsNets) – Tutorial](https://youtu.be/pPN8d0E3900) — Aurélien Géron
- [Understanding Hinton’s Capsule Networks. Part I: Intuition.](https://medium.com/ai³-theory-practice-business/understanding-hintons-capsule-networks-part-i-intuition-b4b559d1159b) — Max Pechyonkin
- [Capsules for Object Segmentation](https://arxiv.org/abs/1804.04241) — Rodney LaLonde, Ulas Bagci
- [Brain Tumor Type Classification via Capsule Networks](https://arxiv.org/abs/1802.10200) — Parnian Afshar, Arash Mohammadi, Konstantinos N. Plataniotis
- [A Tensorflow implementation of CapsNet](https://github.com/naturomics/CapsNet-Tensorflow) — Huadong Liao

### 2. Autonomous Agents

> "**_No superintelligent AI is going to bother with a task that is harder than hacking its reward function._**" — The Lebowski theorem

#### 2.1 Evolution Strategies

- [A Visual Guide to Evolution Strategies](http://blog.otoro.net/2017/10/29/visual-evolution-strategies/) — David Ha
- [Evolution Strategies as a Scalable Alternative to Reinforcement Learning](https://blog.openai.com/evolution-strategies/) — OpenAI
- [The Surprising Creativity of Digital Evolution: A Collection of Anecdotes from the Evolutionary Computation and Artificial Life Research Communities](https://arxiv.org/abs/1803.03453) — Joel Lehman, Jeff Clune, Dusan Misevic, Christoph Adami, Lee Altenberg, Julie Beaulieu, Peter J. Bentley, Samuel Bernard, Guillaume Beslon, David M. Bryson, Patryk Chrabaszcz, Nick Cheney, Antoine Cully, Stephane Doncieux, Fred C. Dyer, Kai Olav Ellefsen, Robert Feldt, Stephan Fischer, Stephanie Forrest, Antoine Frénoy, Christian Gagné, Leni Le Goff, Laura M. Grabowski, Babak Hodjat, Frank Hutter, Laurent Keller, Carole Knibbe, Peter Krcah, Richard E. Lenski, Hod Lipson, Robert MacCurdy, Carlos Maestre, Risto Miikkulainen, Sara Mitri, David E. Moriarty, Jean-Baptiste Mouret, Anh Nguyen, Charles Ofria, Marc Parizeau, David Parsons, Robert T. Pennock, William F. Punch, Thomas S. Ray, Marc Schoenauer, Eric Shulte, Karl Sims, Kenneth O. Stanley, François Taddei, Danesh Tarapore, et al. (4 additional authors not shown)
- [Evolved Policy Gradients](https://arxiv.org/abs/1802.04821) — Rein Houthooft, Richard Y. Chen, Phillip Isola, Bradly C. Stadie, Filip Wolski, Jonathan Ho, Pieter Abbeel
- [Using Evolutionary AutoML to Discover Neural Network Architectures](https://ai.googleblog.com/2018/03/using-evolutionary-automl-to-discover.html) — Google AI

#### 2.2 Deep Reinforcement Learning

- [Reinforcement Learning: An Introduction](https://drive.google.com/file/d/1opPSz5AZ_kVa1uWOdOiveNiBFiEOHjkG/view) — Andrew Barto and Richard S. Sutton
- [Spinning Up as a Deep RL Researcher](https://spinningup.openai.com/en/latest/spinningup/spinningup.html) — Joshua Achiam
- [Intuitive RL: Intro to Advantage-Actor-Critic (A2C)](https://medium.com/@rudygilman/intuitive-rl-intro-to-advantage-actor-critic-a2c-4ff545978752) — Rudy Gilman
- [Simple Beginner’s guide to Reinforcement Learning & its implementation](https://www.analyticsvidhya.com/blog/2017/01/introduction-to-reinforcement-learning-implementation/) — Faizan Shaikh
- [Spinning Up in Deep RL](https://blog.openai.com/spinning-up-in-deep-rl/) — Joshua Achiam
- [Welcome to Spinning Up in Deep RL!](https://spinningup.openai.com/en/latest/) — OpenAI
- [A (Long) Peek into Reinforcement Learning](https://lilianweng.github.io/lil-log/2018/02/19/a-long-peek-into-reinforcement-learning.html#sarsa-on-policy-td-control) — Lilian Weng
- [Monte Carlo Tree Search – beginners guide](https://buff.ly/2Gpr0Gm) — Kamil Czarnogórski
- [Quantifying Generalization in Reinforcement Learning](https://blog.openai.com/quantifying-generalization-in-reinforcement-learning/) — OpenAI
- [Getting Started With MarathonEnvs v0.5.0a](https://medium.com/@Joebooth/gettingstartedwithmarathonenvs-v0-5-0a-c1054a0b540c) — Joe Booth
- [AlphaZero: Shedding new light on the grand games of chess, shogi and Go](https://deepmind.com/blog/alphazero-shedding-new-light-grand-games-chess-shogi-and-go/) — David Silver, Thomas Hubert, Julian Schrittwieser, Ioannis Antonoglou, Matthew Lai, Arthur Guez, Marc Lanctot, Laurent Sifre, Dharshan Kumaran, Thore Graepel, Timothy Lillicrap, Karen Simonyan, Demis Hassabis
- [DQN Adventure: from Zero to State of the Art](https://github.com/higgsfield/RL-Adventure) — higgsfield
- [SURREAL: Open-Source Reinforcement Learning Framework and Robot Manipulation Benchmark](https://surreal.stanford.edu) — Linxi Fan, Yuke Zhu, Jiren Zhu, Zihua Liu, Anchit Gupta, Joan Creus-Costa, Silvio Savarese, Li Fei-Fei
- [Learning to Act by Predicting the Future](https://arxiv.org/abs/1611.01779) — Alexey Dosovitskiy, Vladlen Koltun
- [AlphaFold: Using AI for scientific discovery](https://deepmind.com/blog/alphafold/) — Andrew Senior, John Jumper, Demis Hassabis
- [Reinforcement Learning with Prediction-Based Rewards](https://blog.openai.com/reinforcement-learning-with-prediction-based-rewards/) — Yura Burda, Harri Edwards, OpenAI
- Playing hard exploration games by watching YouTube [Paper](https://papers.nips.cc/paper/7557-playing-hard-exploration-games-by-watching-youtube.pdf) | [YouTube](https://www.youtube.com/watch?v=s8ZSVfYmtpc&feature=youtu.be) — Yusuf Aytar, Tobias Pfaff, David Budden, Tom Le Paine, Ziyu Wang, Nando de Freitas
- Exploration by Random Network Distillation [Paper](https://arxiv.org/abs/1810.12894) | [Code](https://github.com/openai/random-network-distillation) — Yuri Burda, Harrison Edwards, Amos Storkey, Oleg Klimov
- Large-Scale Study of Curiosity-Driven Learning [Paper](https://arxiv.org/abs/1808.04355) | [Code](https://github.com/openai/large-scale-curiosity) — Yuri Burda, Harri Edwards, Deepak Pathak, Amos Storkey, Trevor Darrell, Alexei A. Efros
- [OpenAI Baselines : A2C | ACER | ACKTR | DDPG | DQN | GAIL | HER | PPO2 | TRPO](https://github.com/openai/baselines) — OpenAI
- Stable Baselines is a set of improved implementations of Reinforcement Learning (RL) algorithms based on OpenAI Baselines [Docs](https://stable-baselines.readthedocs.io/en/master/) | [Blog](https://towardsdatascience.com/stable-baselines-a-fork-of-openai-baselines-reinforcement-learning-made-easy-df87c4b2fc82) | [Code](https://github.com/hill-a/stable-baselines) — Antonin Raffin
- TRPO-GAE [Blog](https://blog.openai.com/openai-baselines-ppo/) | [arXiv](https://arxiv.org/pdf/1502.05477.pdf) | [arXiv](https://arxiv.org/pdf/1506.02438.pdf) — OpenAI
- [Improvised Robotic Design with Found Objects](https://nips2018creativity.github.io/doc/improvised_robotic_design.pdf) — Azumi Maekawa, Ayaka Kume, Hironori Yoshida, Jun Hatori, Jason Naradowsky, Shunta Saito
- A3C [arXiv](https://arxiv.org/pdf/1602.01783.pdf) | [Medium](https://medium.com/emergent-future/simple-reinforcement-learning-with-tensorflow-part-8-asynchronous-actor-critic-agents-a3c-c88f72a5e9f2) | [Code](https://github.com/openai/universe-starter-agent) — OpenAI
- [Deep Reinforcement Learning](http://rail.eecs.berkeley.edu/deeprlcourse/) — Sergey Levine
- [Vel: PyTorch meets baselines](https://blog.millionintegrals.com/vel-pytorch-meets-baselines/) — Jerry
- [Actor-Critic Policy Optimization in Partially Observable Multiagent Environments](https://arxiv.org/abs/1810.09026) — Sriram Srinivasan, Marc Lanctot, Vinicius Zambaldi, Julien Perolat, Karl Tuyls, Remi Munos, Michael Bowling
- [TensorFlow Reinforcement Learning](https://github.com/deepmind/trfl/) — DeepMind
- [TensorFlow Agents](https://github.com/tensorflow/agents) — TensorFlow
- [DiCE: The Infinitely Differentiable Monte Carlo Estimator](http://whirl.cs.ox.ac.uk/blog/dice-the-infinitely-differentiable-monte-carlo-estimator/) — Vitaly Kurin, Jakob Foerster, Shimon Whiteson
- [TorchCraftAI: A bot platform for machine learning research on StarCraft®: Brood War®](https://torchcraft.github.io/TorchCraftAI/) — Facebook
- [Curiosity and Procrastination in Reinforcement Learning](https://ai.googleblog.com/2018/10/curiosity-and-procrastination-in.html) — Nikolay Savinov, Timothy Lillicrap
- [Hierarchical Actor-Critic](https://arxiv.org/abs/1712.00948) — Andrew Levy, Robert Platt, Kate Saenko
- [Montezuma’s Revenge Solved by Go-Explore, a New Algorithm for Hard-Exploration Problems](http://eng.uber.com/go-explore/) — Adrien Ecoffet, Joost Huizinga, Joel Lehman, Kenneth O. Stanley, Jeff Clune
- [Computational Theories of Curiosity-Driven Learning](https://arxiv.org/abs/1802.10546) — Pierre-Yves Oudeyer
- [Depth-Limited Solving for Imperfect-Information Games](https://arxiv.org/abs/1805.08195) — Noam Brown, Tuomas Sandholm, Brandon Amos
- [Optimizing Expectations: From Deep Reinforcement Learning to Stochastic Computation Graphs](http://joschu.net/docs/thesis.pdf) — John Schulman
- [Neural Episodic Control](https://arxiv.org/abs/1703.01988) — Alexander Pritzel, Benigno Uria, Sriram Srinivasan, Adrià Puigdomènech, Oriol Vinyals, Demis Hassabis, Daan Wierstra, Charles Blundell
- [RLlib: Abstractions for Distributed Reinforcement Learning](http://arxiv.org/abs/1712.09381) — Eric Liang, Richard Liaw, Philipp Moritz, Robert Nishihara, Roy Fox, Ken Goldberg, Joseph E. Gonzalez, Michael I. Jordan, Ion Stoica
- [TreeQN and ATreeC: Differentiable Tree-Structured Models for Deep Reinforcement Learning](https://arxiv.org/abs/1710.11417) — Gregory Farquhar, Tim Rocktäschel, Maximilian Igl, Shimon Whiteson
- [Q-map: a Convolutional Approach for Goal-Oriented Reinforcement Learning](https://arxiv.org/abs/1810.02927) — Fabio Pardo, Vitaly Levdik, Petar Kormushev
- [Learning to Search with MCTSnets](https://arxiv.org/abs/1802.04697) — Arthur Guez, Théophane Weber, Ioannis Antonoglou, Karen Simonyan, Oriol Vinyals, Daan Wierstra, Rémi Munos, David Silver
- [Convergence of Value Aggregation for Imitation Learning](https://arxiv.org/abs/1801.07292) — Ching-An Cheng, Byron Boots
- [Dopamine : DQN | C51 | Rainbow | Implicit Quantile Network](https://github.com/google/dopamine) — Marc G. Bellemare, Pablo Samuel Castro, Carles Gelada, Saurabh Kumar, Subhodeep Moitra
- [S-RL Toolbox: Reinforcement Learning (RL) and State Representation Learning (SRL) for Robotics](https://github.com/araffin/robotics-rl-srl) — Antonin RAFFIN
- [Advanced Deep Learning and Reinforcement Learning](https://www.youtube.com/playlist?list=PLqYmG7hTraZDNJre23vqCGIVpfZ_K2RZs) — DeepMind Researchers
- Reinforcement Learning for Improving Agent Design [arXiv](https://arxiv.org/abs/1810.03779) | [Blog](https://designrl.github.io) — David Ha
- Deep Reinforcement Learning from Human Preferences [arXiv](https://arxiv.org/pdf/1706.03741.pdf) | [Blog](https://blog.openai.com/gathering_human_feedback/) | [Code](https://github.com/nottombrown/rl-teacher) — OpenAI
- [Introduction to Learning to Trade with Reinforcement Learning](http://www.wildml.com/2018/02/introduction-to-learning-to-trade-with-reinforcement-learning/) — Denny Britz
- [Closing the Sim-to-Real Loop: Adapting Simulation Randomization with Real World Experience](https://arxiv.org/abs/1810.05687) — Yevgen Chebotar, Ankur Handa, Viktor Makoviychuk, Miles Macklin, Jan Issac, Nathan Ratliff, Dieter Fox
- [Robustness via Retrying: Closed-Loop Robotic Manipulation with Self-Supervised Learning](https://sites.google.com/view/robustness-via-retrying) — Frederik Ebert, Sudeep Dasari, Alex X. Lee, Sergey Levine, Chelsea Finn
- [CURIOUS: Intrinsically Motivated Multi-Task, Multi-Goal Reinforcement Learning](https://arxiv.org/abs/1810.06284) — Cédric Colas, Olivier Sigaud, Pierre-Yves Oudeyer
- [One-Shot High-Fidelity Imitation: Training Large-Scale Deep Nets with RL](https://arxiv.org/abs/1810.05017) — Tom Le Paine, Sergio Gómez Colmenarejo, Ziyu Wang, Scott Reed, Yusuf Aytar, Tobias Pfaff, Matt W. Hoffman, Gabriel Barth-Maron, Serkan Cabi, David Budden, Nando de Freitas
- [Optimizing Agent Behavior over Long Time Scales by Transporting Value](https://arxiv.org/abs/1810.06721) — Chia-Chun Hung, Timothy Lillicrap, Josh Abramson, Yan Wu, Mehdi Mirza, Federico Carnevale, Arun Ahuja, Greg Wayne
- [Large-Scale Study of Curiosity-Driven Learning](https://pathak22.github.io/large-scale-curiosity/) — Yuri Burda, Harri Edwards, Deepak Pathak, Amos Storkey, Trevor Darrell, Alexei A. Efros
- [Learning to Dress: Synthesizing Human Dressing Motion via Deep Reinforcement Learning](https://www.cc.gatech.edu/~aclegg3/projects/LearningToDress.html) — Alexander Clegg, Wenhao Yu, Jie Tan, C. Karen Liu, Greg Turk, SIGGRAPH Asia 2018
- [Automatic Poetry Generation with Mutual Reinforcement Learning](http://aclweb.org/anthology/D18-1353) — Xiaoyuan Yi, Maosong Sun, Ruoyu Li, Wenhao Li
- [Learning to Communicate with Deep Multi-Agent Reinforcement Learning in PyTorch](https://github.com/minqi/learning-to-communicate-pytorch) — Minqi Jiang
- [Learning to Navigate the Web](https://openreview.net/forum?id=BJemQ209FQ) — Anonymous
- [Understanding & Generalizing AlphaGo Zero](https://openreview.net/forum?id=rkxtl3C5YX) — Anonymous
- [Deep RL Bootcamp](https://sites.google.com/view/deep-rl-bootcamp/lectures) — Pieter Abbeel, Yan (Rocky) Duan, Xi (Peter) Chen, Andrej Karpathy

#### 2.3 Self Play

[![AlphaGo Zero : Algorithms matter much more than big data and massive amounts of computation](../images/AlphaGoZero.mp4 "AlphaGo Zero : Algorithms matter much more than big data and massive amounts of computation")](https://deepmind.com/blog/alphago-zero-learning-scratch/)

- [Deep Learning: AlphaGo Zero Explained In One Picture](https://www.datasciencecentral.com/profiles/blogs/deep-learning-alphago-zero-explained-in-one-picture) — L.V.
- [How to build your own AlphaZero AI using Python and Keras](https://medium.com/applied-data-science/how-to-build-your-own-alphazero-ai-using-python-and-keras-7f664945c188) — David Foster
- [An open-source implementation of the AlphaGoZero algorithm](https://github.com/tensorflow/minigo) — TensorFlow

> "**_Self-Play is Automated Knowledge Creation._**" — Carlos E. Perez

#### 2.4 Multi-Agent Populations

- [Machine Theory of Mind](https://arxiv.org/abs/1802.07740) — Rabinowitz et al.
- [A Unified Game-Theoretic Approach to Multiagent Reinforcement Learning](https://arxiv.org/pdf/1711.00832.pdf) — Lanctot et al.
- [Continuous Adaptation via Meta-Learning in Nonstationary and Competitive Environments](https://arxiv.org/pdf/1710.03641.pdf) — Al-Shedivat et al.
- [Autonomous Agents Modelling Other Agents: A Comprehensive Survey and Open Problems](http://www.cs.utexas.edu/~pstone/Papers/bib2html-links/AIJ18-Albrecht.pdf) — Stefano V. Albrecht, Peter Stone
- Learning with Opponent-Learning Awareness [Paper](https://arxiv.org/pdf/1709.04326.pdf) | [Blog](https://blog.openai.com/learning-to-model-other-minds/) — OpenAI
- GPU-Accelerated Robotic Simulation for Distributed Reinforcement Learning [Paper](https://arxiv.org/abs/1810.05762) | [Blog](https://news.developer.nvidia.com/nvidia-researchers-develop-reinforcement-learning-algorithm-to-train-thousands-of-robots-simultaneously/) — Jacky Liang, Viktor Makoviychuk, Ankur Handa, Nuttapong Chentanez, Miles Macklin, Dieter Fox, NVIDIA
- Multi-Agent Actor-Critic for Mixed Cooperative-Competitive Environments [Paper](https://arxiv.org/pdf/1706.02275.pdf) | [Blog](https://blog.openai.com/learning-to-cooperate-compete-and-communicate/) | [Code](https://github.com/openai/maddpg/) — OpenAI

#### 2.5 Deep Meta-Learning

- Learning to Learn [Paper](https://arxiv.org/pdf/1606.04474.pdf) | [Code](https://github.com/deepmind/learning-to-learn) — Google DeepMind, University of Oxford, Canadian Institute for Advanced Research
- [Model-Agnostic Meta-Learning for Fast Adaptation of Deep Networks](https://arxiv.org/abs/1703.03400) — Chelsea Finn, Pieter Abbeel, Sergey Levine
- [AutoML: Methods, Systems, Challenges](https://www.automl.org/book/) — Frank Hutter, Lars Kotthoff, Joaquin Vanschoren
- [Talos: Hyperparameter Scanning and Optimization for Keras](https://github.com/autonomio/talos) — Autonomio
- Efficient Neural Architecture Search via Parameter Sharing [Paper](https://arxiv.org/abs/1802.03268) | [Code](https://github.com/melodyguan/enas) — Hieu Pham, Melody Y. Guan, Barret Zoph, Quoc V. Le, Jeff Dean
- Meta-Learning Shared Hierarchies [Paper](https://arxiv.org/abs/1710.09767) | [Blog](https://blog.openai.com/learning-a-hierarchy/) | [Code](https://github.com/openai/mlsh) — OpenAI
- [Reptile: A Scalable Meta-Learning Algorithm](https://github.com/openai/supervised-reptile) — Alex Nichol, John Schulman
- [Learning Shared Dynamics with Meta-World Models](https://arxiv.org/abs/1811.01741) — Lisheng Wu, Minne Li, Jun Wang
- [NIPS2017 Meta Learning Symposium videos](http://metalearning-symposium.ml/) — NIPS 2017

#### 2.6 Generative Adversarial Network

- [Generative Models](https://blog.openai.com/generative-models/) — OpenAI
- [GAN Lab: Play with Generative Adversarial Networks (GANs) in your browser!](https://poloclub.github.io/ganlab/) — Minsuk Kahng, Nikhil Thorat, Polo Chau, Fernanda Viégas, Martin Wattenberg
- [Generative Adversarial Networks (GANs) in 50 lines of code (PyTorch)](https://medium.com/@devnag/generative-adversarial-networks-gans-in-50-lines-of-code-pytorch-e81b79659e3f) — Dev Nag
- [TensorFlow-GAN (TFGAN)](https://github.com/tensorflow/tensorflow/tree/master/tensorflow/contrib/gan) — TensorFlow
- Bayesian GAN [arXiv](https://arxiv.org/abs/1705.09558) | [GitHub](https://github.com/andrewgordonwilson/bayesgan/) — Yunus Saatchi, Andrew Gordon Wilson
- [Generating Memoji from Photos](https://patniemeyer.github.io/2018/10/29/generating-memoji-from-photos.html) — Pat Niemeyer
- Recycle-GAN: Unsupervised Video Retargeting [Paper](http://www.cs.cmu.edu/~aayushb/Recycle-GAN/recycle_gan.pdf) | [Blog](http://www.cs.cmu.edu/~aayushb/Recycle-GAN/) — Aayush Bansal, Shugao Ma, Deva Ramanan, Yaser Sheikh
- A collection of GANs [TensorFlow](https://github.com/hwalsuklee/tensorflow-generative-model-collections) | [PyTorch](https://github.com/znxlwm/pytorch-generative-model-collections)

> "**_What I cannot create, I do not understand._**" — Richard Feynman

#### 2.7 World Models

- [World Models](https://worldmodels.github.io) — David Ha, Jürgen Schmidhuber
- [Imagination-Augmented Agents for Deep Reinforcement Learning](https://arxiv.org/abs/1707.06203) — Théophane Weber, Sébastien Racanière, David P. Reichert, Lars Buesing, Arthur Guez, Danilo Jimenez Rezende, Adria Puigdomènech Badia, Oriol Vinyals, Nicolas Heess, Yujia Li, Razvan Pascanu, Peter Battaglia, Demis Hassabis, David Silver, Daan Wierstra

### 3. Environments

#### 3.1 OpenAI Gym

- OpenAI Gym [WebSite](https://gym.openai.com) | [Blog](https://blog.openai.com/openai-gym-beta/) | [GitHub](https://github.com/openai/gym) | [White Paper](http://arxiv.org/abs/1606.01540) — OpenAI

#### 3.2 Unity ML-Agents

- Unity ML-Agents [WebSite](https://unity3d.ai) | [GitHub](https://github.com/Unity-Technologies/ml-agents) | [Documentation](https://github.com/Unity-Technologies/ml-agents/tree/master/docs) | [Challenge I](https://connect.unity.com/challenges/ml-agents-1) — Unity Technologies
- [Puppo, The Corgi: Cuteness Overload with the Unity ML-Agents Toolkit](https://blogs.unity3d.com/2018/10/02/puppo-the-corgi-cuteness-overload-with-the-unity-ml-agents-toolkit/) — Vincent-Pierre Berges, Leon Chen

#### 3.3 DeepMind Control Suite

- DeepMind Control Suite [Paper](https://arxiv.org/abs/1801.00690) | [GitHub](https://github.com/deepmind/dm_control) | [Video](https://youtu.be/rAai4QzcYbs) — DeepMind

#### 3.4 Brigham Young University | Holodeck

- BYU Holodeck: A high-fidelity simulator for deep reinforcement learning [Website](https://holodeck.cs.byu.edu) | [GitHub](https://github.com/byu-pccl/holodeck) | [Documentation](https://holodeck.readthedocs.io/en/latest/) — Brigham Young University

#### 3.5 Facebook's Horizon

- Horizon: Facebook's Open Source Applied Reinforcement Learning Platform [Paper](https://arxiv.org/abs/1811.00260) | [GitHub](https://github.com/facebookresearch/Horizon) | [Blog](https://research.fb.com/publications/horizon-facebooks-open-source-applied-reinforcement-learning-platform/) — Jason Gauci, Edoardo Conti, Yitao Liang, Kittipat Virochsiri, Yuchen He, Zachary Kaden, Vivek Narayanan, Xiaohui Ye

#### 3.6 PhysX

- PhysX SDK, an Open-Source Physics Engine [GitHub](https://github.com/NVIDIAGameWorks/PhysX-3.4) | [Blog](https://news.developer.nvidia.com/announcing-physx-sdk-4-0-an-open-source-physics-engine/?linkId=100000004228364) — NVIDIA

### 4. General Readings, Ressources and Tools

- [Building safe artificial intelligence: specification, robustness, and assurance](https://medium.com/@deepmindsafetyresearch/building-safe-artificial-intelligence-52f5f75058f1) — Pedro A. Ortega, Vishal Maini, and the DeepMind safety team
- [Google Dataset Search Beta](https://toolbox.google.com/datasetsearch) — Google
- [Papers with Code](https://paperswithcode.com) — Papers with Code
- [GitXiv | arXiv + CODE](http://www.gitxiv.com) — Collaborative Open Computer Science
- [The Vulnerable World Hypothesis](https://nickbostrom.com/papers/vulnerable.pdf) — Nick Bostrom
- Scalable agent alignment via reward modeling [Medium](https://medium.com/@deepmindsafetyresearch/scalable-agent-alignment-via-reward-modeling-bf4ab06dfd84) | [arXiv](https://arxiv.org/pdf/1811.07871.pdf) — Jan Leike, David Krueger, Tom Everitt, Miljan Martic, Vishal Maini, Shane Legg
- [ASILOMAR AI PRINCIPLES](https://futureoflife.org/ai-principles/) — The 2017 Asilomar conference
- [Strategic Implications of Openness in AI Development](https://nickbostrom.com/papers/openness.pdf) — Nick Bostrom
- [teleportHQ ThinkToCode ecosystem](https://twitter.com/TeleportHQio/status/1043245039261044736) — teleportHQ
- [Statistical physics of liquid brains](https://www.biorxiv.org/content/biorxiv/early/2018/11/26/478412.full.pdf) — Jordi Pinero and Ricard Sole
- [Interpretable Machine Learning](https://christophm.github.io/interpretable-ml-book/) — Christoph Molnar
- [Building a Winning Self-Driving Car in Six Months](https://arxiv.org/abs/1811.01273) — Keenan Burnett, Andreas Schimpe, Sepehr Samavi, Mona Gridseth, Chengzhi Winston Liu, Qiyang Li, Zachary Kroeze, Angela P. Schoellig
- [Une intelligence artificielle bien réelle : les termes de l'IA](https://www.oqlf.gouv.qc.ca/ressources/bibliotheque/dictionnaires/vocabulaire-intelligence-artificielle.aspx) — Office québécois de la langue française
- [How to deliver on Machine Learning projects](https://blog.insightdatascience.com/how-to-deliver-on-machine-learning-projects-c8d82ce642b0) — Emmanuel Ameisen
- [The Malicious Use of Artificial Intelligence: Forecasting, Prevention, and Mitigation](https://arxiv.org/pdf/1802.07228.pdf) — Miles Brundage, Shahar Avin, Jack Clark, Helen Toner, Peter Eckersley, Ben Garfinkel, Allan Dafoe, Paul Scharre, Thomas Zeitzoff, Bobby Filar, Hyrum Anderson, Heather Roff, Gregory C. Allen, Jacob Steinhardt, Carrick Flynn, Seán Ó hÉigeartaigh, Simon Beard, Haydn Belfield, Sebastian Farquhar, Clare Lyle, Rebecca Crootof, Owain Evans, Michael Page, Joanna Bryson, Roman Yampolskiy, Dario Amodei
- [Machine Learning for Combinatorial Optimization: a Methodological Tour d'Horizon](https://arxiv.org/abs/1811.06128) — Yoshua Bengio, Andrea Lodi, Antoine Prouvost
- [26-Year-Old Nigerian Creates First Gaming Robot](https://www.ebony.com/news-views/26-year-old-nigerian-engineer-first-gaming-robot) — Christina Santi
- [Machine Learning Top 10 Articles for the Past Month (v.Oct 2018)](https://medium.mybridge.co/machine-learning-top-10-articles-for-the-past-month-v-oct-2018-ca24dadbe495) — Mybridge
- [Is artificial intelligence set to become art’s next medium?](https://www.christies.com/features/A-collaboration-between-two-artists-one-human-one-a-machine-9332-1.aspx) — Jonathan Bastable, Christie’s
- [An Artificial Neuron Implemented on an Actual Quantum Processor](https://arxiv.org/abs/1811.02266) — Tacchino et al.
- [Efficiently measuring a quantum device using machine learning](https://arxiv.org/abs/1810.10042) — D.T. Lennon, H. Moon, L.C. Camenzind, Liuqi Yu, D.M. Zumbühl, G.A.D. Briggs, M.A. Osborne, E.A. Laird, N. Ares
- [Deep Learning : Current Limits and What Lies Beyond Them](https://youtu.be/2L2u303FAs8) — François Chollet
- [Poker | Solving Imperfect-Information Games via Discounted Regret Minimization](hhttps://arxiv.org/abs/1809.04040) — Noam Brown, Tuomas Sandholm
- [The Illustrated BERT, ELMo, and co. (How NLP Cracked Transfer Learning)](https://jalammar.github.io/illustrated-bert/) — Jay Alammar
- [Learning to Infer Graphics Programs from Hand-Drawn Images](https://arxiv.org/abs/1707.09627) — Kevin Ellis, Daniel Ritchie, Armando Solar-Lezama, Joshua B. Tenenbaum
- [TensorFlow code and pre-trained models for BERT (Bidirectional Encoder Representations from Transformers)](https://github.com/google-research/bert) — Jacob Devlin, Ming-Wei Chang, Kenton Lee, Kristina Toutanova
- [The Superintelligent Will: Motivation and Instrumental Rationality in Advanced Artificial Agents](https://nickbostrom.com/superintelligentwill.pdf) — Nick Bostrom
- [MobiLimb: Augmenting Mobile Devices with a Robotic Limb](https://www.marcteyssier.com/projects/mobilimb/) — Marc Teyssier, Gilles Bailly, Catherine Pelachaud, Eric Lecolinet
- [32-Legged Spherical Robot Moves Like an Amoeba](https://spectrum.ieee.org/automaton/robotics/robotics-hardware/32-legged-spherical-robot-moves-like-an-amoeba) — Evan Ackerman, IEEE Spectrum
- [On winning all the big academic recent competitions. Presentation.](http://presentations.cocodataset.org/COCO17-Detect-Megvii.pdf) — Megvii (Face++) Team
- [Stanford AI recreates chemistry’s periodic table of elements](https://news.stanford.edu/2018/06/25/ai-recreates-chemistrys-periodic-table-elements/) — Ker Than
- [Neural Approaches to Conversational AI](https://arxiv.org/abs/1809.08267) — Jianfeng Gao, Michel Galley, Lihong Li
- [Learned optimizers that outperform SGD on wall-clock and validation loss](https://arxiv.org/abs/1810.10180) — Luke Metz, Niru Maheswaranathan, Jeremy Nixon, C. Daniel Freeman, Jascha Sohl-Dickstein
- [Beauty and the Beast: Optimal Methods Meet Learning for Drone Racing](https://arxiv.org/abs/1810.06224) — Elia Kaufmann, Mathias Gehrig, Philipp Foehn, René Ranftl, Alexey Dosovitskiy, Vladlen Koltun, Davide Scaramuzza
- [Writing Code for NLP Research](https://docs.google.com/presentation/d/17NoJY2SnC2UMbVegaRCWA7Oca7UCZ3vHnMqBV4SUayc/preview?slide=id.p) — Allen Institute for Artificial Intelligence
- [Autonomous Tidying-up Robot System](https://projects.preferred.jp/tidying-up-robot/en/) — Preferred Networks
- [Emerging Technology and Ethics Research Guide – v 1.0](https://danyaglabau.com/2018/11/05/emerging-technology-and-ethics-research-guide-v-1-0/) — Danya Glabau
- [Machine learning and artificial intelligence in the quantum domain](https://arxiv.org/abs/1709.02779) — Vedran Dunjko, Hans J. Briegel
- [Playing Mortal Kombat with TensorFlow.js. Transfer learning and data augmentation](https://blog.mgechev.com/2018/10/20/transfer-learning-tensorflow-js-data-augmentation-mobile-net/) — Minko Gechev
- [A series on quantum computing? Welcome to QuantumCasts!](https://youtu.be/hpHfzYTOMGI) — Marissa Giustina
- [NLP.js : a general natural language utilities for nodejs](https://github.com/axa-group/nlp.js) — AXA Shared Services Spain S.A.
- Hierarchical Multi-Task Learning model: One NLP model to rule them all! [Medium](https://medium.com/huggingface/beating-the-state-of-the-art-in-nlp-with-hmtl-b4e1d5c3faf) | [Demo](https://huggingface.co/hmtl/) | [Code](https://github.com/huggingface/hmtl/tree/master/demo) — Hugging Face
- [Constructing exact representations of quantum many-body systems with deep neural networks](https://arxiv.org/pdf/1802.09558.pdf) — Giuseppe Carleo
- [Over 200 of the Best Machine Learning, NLP, and Python Tutorials — 2018 Edition](https://medium.com/machine-learning-in-practice/over-200-of-the-best-machine-learning-nlp-and-python-tutorials-2018-edition-dd8cf53cb7dc) — Robbie Allen
- [Deep Learning Papers Reading Roadmap](https://github.com/floodsung/Deep-Learning-Papers-Reading-Roadmap) — Flood Sung
- [Open Courses and Textbooks](https://sgfin.github.io/learning-resources/) — Samuel G. Finlayson
- [~250 awesome short lectures on robotics](https://robotacademy.net.au) — Queensland University of Technology Robot Academy
- [The Best Textbooks on Every Subject](https://www.lesswrong.com/posts/xg3hXCYQPJkwHyik2/the-best-textbooks-on-every-subject) — lukeprog

> "**_ML paper writing pro-tip: you can download the raw source of any arxiv paper. Click on the "Other formats" link, then click "Download source". This gets you a .tar.gz with all the .tex files, all the image files for the figures in their original resolution, etc._**" — Ian Goodfellow

__Réservation de groupe:__

✉️ __Courriel__ : info@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.montreal.ai/
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Secrétariat Général de Montréal.IA__ : 350, RUE PRINCE-ARTHUR OUEST, SUITE #2105, MONTRÉAL [QC], CANADA, H2X 3R4 **Conseil exécutif et bureau administratif*

#__IA101__ #__IntelligenceArtificielle__ #__IntelligenceArtificielle101__ #__IntelligenceArtificielleMontreal__ #__MontrealIA__
