---
title: MONTRÉAL.IA | Intelligence Artificielle Montréal
---
## L’Académie Montréal.IA : Intelligence Artificielle 101

__L'aube de l'intelligence artificielle__

[![AI 101 : The First Comprehensive Overview of AI for the General Public](../images/academy1920cover_v0.jpg "AI 101 : The First Comprehensive Overview of AI for the General Public")](http://montreal.ai/academy.pdf)

## Le premier aperçu complet de l'IA pour le grand public

__IA 101 : Un didacticiel de 75 minutes exécutable et bien conçu__

PUISSANT ET UTILE. Ce tutoriel pratique est conçu pour offrir à tous l'état d'esprit, les compétences et les outils nécessaires pour voir l'intelligence artificielle d'un nouveau point de vue stimulant :

— Des découvertes et des connaissances scientifiques de pointe ;
— Les meilleurs codes et implémentations __*open source*__ ; et
— L'impulsion qui anime l'intelligence artificielle d'aujourd'hui.

L’Académie Montréal.IA : Formation des individus qui, avec l'IA, façonneront le 21ème siècle.

## #AI4Artists : Des créations légendaires pionnières

__*#AI4Artists*__ est conçu pour inspirer les artistes qui, avec l’intelligence artificielle, façonneront le 21ème siècle. 

[![AI4Artists : Le premier aperçu complet (全) de l'IA pour les artistes](../images/AI4ArtistsProgram_v4.jpg "AI4Artists : Le premier aperçu complet (全) de l'IA pour les artistes")](http://www.montreal.ai/AI4Artists.pdf)

<p data-height="265" data-theme-id="0" data-slug-hash="xaGVOX" data-default-tab="js,result" data-user="QuebecAI" data-pen-title="Quebec.AI's Bubble Bath" class="codepen">See the Pen <a href="https://codepen.io/QuebecAI/pen/xaGVOX/">Quebec.AI's Bubble Bath</a> by QuebecAI (forked from Tero Parviainen) (<a href="https://codepen.io/QuebecAI">@QuebecAI</a>) on <a href="https://codepen.io">CodePen</a>.</p>
<script async src="https://static.codepen.io/assets/embed/ei.js"></script>

__MONTRÉAL.IA | Intelligence Artificielle Montréal__ offre la plus importante communauté en intelligence artificielle au Canada. **_Rejoignez-nous et apprenez!_** https://www.facebook.com/groups/MontrealAI/

> "**_Les artistes qui créent avec l'IA ne suivront pas les tendances; ILS VONT LES DÉFINIR._**" — Vincent Boucher, B. Sc. Physique théorique, M. A. Analyse des politiques gouvernementales, M. Sc. Génie aérospatial et Chef de la direction d'Intelligence Artificielle Montréal ❖ Montréal.AI

###### ＊ _Ce tutoriel de 75 minutes est actuellement en version alpha, avec un nombre limité de clients pour nous aider à l'affûter. Quand nous aborderons la version bêta, nous accueillerons plus de groupes __*(150 personnes et plus)*__ sur la liste d'attente._

✉️ __Réservations pour les groupes__ : academie@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.academie.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Maison-mère__ : 350, rue Prince-Arthur Ouest, suite 2105, Montréal, Qc H2X 3R4 **Bureau administratif*

#__AIFirst__ #__IntelligenceArtificielleMontreal__ #__MontrealAI__
