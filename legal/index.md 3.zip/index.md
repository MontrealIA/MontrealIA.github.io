---
title: MONTRÉAL.IA | Intelligence Artificielle Montréal
---
## AVIS LÉGAL

__​​Information sur la publication [*Ordre exécutif: HQ III M[5-X]*] :__
​​
__​​​​​​Autorité d'approbation :__  Vincent Boucher, Chef de la direction chez Intelligence Artificielle Montréal.
​​
__​​Bureau de la responsabilité principale :__ CONSEIL ANALYSE D'INFORMATIONS STRATÉGIQUES CANADIENNES Inc.

__CECI EST UN LOGICIEL / SYSTÈME D'*INTELLIGENCE ARTIFICIELLE MONTRÉAL*.__

__LES INFORMATIONS DONNÉES PAR CE LOGICIEL / SYSTÈME SONT FOURNIES SANS GARANTIE D'AUCUNE SORTE ET NE CONSTITUENT PAS UNE APPROBATION.__ LE LOGICIEL / SYSTÈME EST FOURNI "TEL QUEL", SANS GARANTIE D'AUCUNE SORTE, EXPLICITE OU IMPLICITE, NOTAMMENT SANS GARANTIE DE QUALITÉ MARCHANDE, D’ADÉQUATION À UN USAGE PARTICULIER ET D'ABSENCE DE CONTREFAÇON. EN AUCUN CAS, LES AUTEURS OU TITULAIRES DU DROIT D'AUTEUR NE SERONT RESPONSABLES DE TOUT DOMMAGE, RÉCLAMATION OU AUTRE RESPONSABILITÉ, QUE CE SOIT DANS LE CADRE D'UN CONTRAT, D'UN DÉLIT OU AUTRE, EN PROVENANCE DE, CONSÉCUTIF À OU EN RELATION AVEC LE LOGICIEL / SYSTÈME OU SON UTILISATION, OU AVEC D'AUTRES ÉLÉMENTS DU LOGICIEL / SYSTÈME.

<p style="text-align: center;">__LA PREUVE D'UTILISATION NON AUTORISÉE PEUT ÊTRE FOURNIE AU PERSONNEL APPROPRIÉ POUR UNE ACTION LÉGALE.__​</p>

​​​​![MONTRÉAL.IA | Intelligence Artificielle Montréal : AVIS LÉGAL](../images/JusticeHQIIIM5.jpg "MONTRÉAL.IA | Intelligence Artificielle Montréal : AVIS LÉGAL")
​
✉️ __Courriel__ : info@montreal.ai
📞 __Téléphone__ : +1.514.829.8269
🌐 __Site web__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai/
🏛 __Maison-mère__ : 350, rue Prince-Arthur Ouest, suite 2105, Montréal, Qc H2X 3R4 **Bureau administratif*

#__AIFirst__ #__IntelligenceArtificielleMontreal__ #__MontrealAI__
